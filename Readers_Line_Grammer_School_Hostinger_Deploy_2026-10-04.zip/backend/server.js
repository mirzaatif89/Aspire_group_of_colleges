const express = require('express');
const fs = require('fs');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');
const cors = require('cors');
const { Sequelize, DataTypes, Op } = require('sequelize');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
const QRCode = require('qrcode');
const { getSmtpConfig, sendSmtpEmail } = require('../api/_lib/mailer');
const { buildFeeReminderEmail } = require('../api/_lib/emailTemplate');
const apiCatalog = require('../api/_lib/apiCatalog');
const { normalizeJsonUpload, parseMultipart, saveUploadedFile } = require('../api/_lib/uploadFile');

// Passenger/cPanel may start Node with the account home as its working
// directory. Always load the .env that belongs to this application root.
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const PROJECT_ROOT = path.resolve(__dirname, '..');
const FRONTEND_DIR = path.join(PROJECT_ROOT, 'frontend');
const DATA_DIR = path.join(PROJECT_ROOT, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const MOBILE_API_STORE_DIR = path.join(DATA_DIR, 'mobile_api_store');
fs.mkdirSync(MOBILE_API_STORE_DIR, { recursive: true });

const JWT_SECRET = process.env.JWT_SECRET || 'eduCore_secret_key_2026';
const PERMISSIONS_FILE = path.join(DATA_DIR, 'permissions.json');
const DETAILED_PERMISSIONS_FILE = path.join(DATA_DIR, 'permissions-detailed.json');
const DATE_SHEET_FILE = path.join(DATA_DIR, 'date_sheet.json');
const ADMIN_CREDENTIALS_FILE = path.join(DATA_DIR, 'admin_credentials.json');
const PRINCIPAL_USERNAME = process.env.PRINCIPAL_USERNAME || 'principal@school.com';
const PRINCIPAL_PASSWORD = process.env.PRINCIPAL_PASSWORD || 'Principal123';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

const corsOptions = {
    origin: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Auth-Token', 'X-Requested-With'],
    credentials: false,
    maxAge: 86400
};

app.disable('x-powered-by');
app.set('trust proxy', true);
app.use(cors(corsOptions));
app.options('*', cors(corsOptions));
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // This is a live admin system, so pages and JavaScript must never be served
    // from an older browser/proxy cache after a local restart or deployment.
    res.setHeader('Cache-Control', 'no-store, max-age=0, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));
const RESERVED_ROUTE_NAMES = new Set(['api', 'health', 'socket.io']);

function resolvePageFileByRoute(routeName = '') {
    const normalized = String(routeName || '').trim().toLowerCase();
    if (!normalized) return '';
    if (RESERVED_ROUTE_NAMES.has(normalized)) return '';
    if (normalized === 'login') return 'login.html';
    if (normalized === 'index' || normalized === 'website') return 'website.html';
    if (!/^[a-z0-9_-]+$/i.test(normalized)) return '';

    const candidate = `${normalized}.html`;
    const candidatePath = path.join(FRONTEND_DIR, candidate);
    return fs.existsSync(candidatePath) ? candidate : '';
}

app.get('/', (_req, res) => {
    res.sendFile(path.join(FRONTEND_DIR, 'website.html'));
});

app.get('/:pageName([a-zA-Z0-9_-]+).html', (req, res, next) => {
    const pageName = String(req.params.pageName || '').toLowerCase();
    if (RESERVED_ROUTE_NAMES.has(pageName)) return next();
    if (pageName === 'designation-permissions') return res.redirect(302, '/permissions');

    const targetRoute = pageName === 'index' ? '' : pageName;
    const targetFile = resolvePageFileByRoute(targetRoute);
    if (!targetFile && targetRoute) return next();

    return res.redirect(302, targetRoute ? `/${targetRoute}` : '/');
});

app.get('/:routeName([a-zA-Z0-9_-]+)', (req, res, next) => {
    if (String(req.params.routeName || '').toLowerCase() === 'designation-permissions') {
        return res.redirect(302, '/permissions');
    }
    const pageFile = resolvePageFileByRoute(req.params.routeName);
    if (!pageFile) return next();
    return res.sendFile(path.join(FRONTEND_DIR, pageFile));
});

app.use(express.static(FRONTEND_DIR));

function readRawRequestBuffer(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        req.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
        req.on('end', () => resolve(Buffer.concat(chunks)));
        req.on('error', reject);
    });
}

app.post('/api/upload', async (req, res) => {
    try {
        const contentType = String(req.headers['content-type'] || '').toLowerCase();
        let fields = req.body && typeof req.body === 'object' ? req.body : {};
        let file = null;

        if (contentType.includes('multipart/form-data')) {
            const parsed = parseMultipart(await readRawRequestBuffer(req), contentType);
            fields = parsed.fields;
            file = parsed.files[0] || null;
        } else {
            file = normalizeJsonUpload(fields);
        }

        const uploadedFile = saveUploadedFile({ req, uploadRoot: FRONTEND_DIR, fields, file });
        res.json({ success: true, file: uploadedFile, url: uploadedFile.url });
    } catch (error) {
        res.status(error.statusCode || 500).json({
            success: false,
            message: error.message || 'File upload failed.'
        });
    }
});

app.get('/health', (_req, res) => {
    res.json({
        success: true,
        initialized: isInitialized,
        timestamp: new Date().toISOString()
    });
});

app.get(['/api/health', '/api/ping'], async (_req, res) => {
    if (!isInitialized) {
        try {
            await startServer();
        } catch (_error) {
            // The response below exposes only a safe status, never credentials.
        }
    }
    res.status(isInitialized ? 200 : 503).json({
        success: isInitialized,
        online: true,
        initialized: isInitialized,
        databaseStatus: isInitialized ? 'ready' : 'error',
        databaseErrorCode: isInitialized ? null : (startupErrorCode || 'DATABASE_STARTUP_FAILED'),
        databaseConfigLoaded: {
            host: Boolean(process.env.DB_HOST),
            name: Boolean(process.env.DB_NAME),
            user: Boolean(process.env.DB_USER),
            password: Boolean(process.env.DB_PASSWORD)
        },
        message: isInitialized ? 'API and database are ready.' : getDatabaseStatusMessage(startupErrorCode),
        timestamp: new Date().toISOString()
    });
});

app.get(['/api/catalog', '/api/mobile-api-list'], (_req, res) => {
    res.json({ success: true, ...apiCatalog });
});

// The HTTP listener can become available before asynchronous database startup
// finishes on cPanel. Hold database-backed routes until their tables are ready.
app.use('/api', async (req, res, next) => {
    if (['/health', '/ping', '/catalog', '/mobile-api-list'].includes(req.path)) {
        return next();
    }

    try {
        await startServer();
        return next();
    } catch (_error) {
        return res.status(503).json({
            success: false,
            databaseErrorCode: startupErrorCode || 'DATABASE_STARTUP_FAILED',
            message: getDatabaseStatusMessage(startupErrorCode)
        });
    }
});

let sequelize;
let startupPromise = null;
let isInitialized = false;
let startupError = null;
let startupErrorCode = null;

function classifyDatabaseError(error) {
    const rawCode = String(error?.original?.code || error?.parent?.code || error?.code || '').toUpperCase();
    const message = String(error?.message || '').toLowerCase();
    if (rawCode === 'ER_ACCESS_DENIED_ERROR' || message.includes('access denied')) return 'INVALID_DATABASE_CREDENTIALS';
    if (rawCode.includes('DBACCESS_DENIED') || message.includes('command denied') || message.includes('permission denied')) return 'DATABASE_PRIVILEGES_MISSING';
    if (rawCode === 'ER_BAD_DB_ERROR' || message.includes('unknown database')) return 'DATABASE_NOT_FOUND';
    if (rawCode === 'ECONNREFUSED' || message.includes('connect econnrefused')) return 'DATABASE_CONNECTION_REFUSED';
    if (rawCode === 'ENOTFOUND' || message.includes('getaddrinfo')) return 'DATABASE_HOST_NOT_FOUND';
    if (rawCode === 'ER_NO_SUCH_TABLE' || message.includes("doesn't exist")) return 'DATABASE_SCHEMA_MISSING';
    return rawCode || 'DATABASE_STARTUP_FAILED';
}

function getDatabaseStatusMessage(code) {
    if (code === 'ER_TOO_BIG_ROWSIZE') return 'The database schema is incompatible with the server row-size limit. Deploy the optimized schema and restart the Node.js application.';
    if (code === 'INVALID_DATABASE_CREDENTIALS') return 'Database login failed. Verify DB_USER and DB_PASSWORD in the application .env file.';
    if (code === 'DATABASE_PRIVILEGES_MISSING') return 'The database user needs ALL PRIVILEGES for the configured database.';
    if (code === 'DATABASE_NOT_FOUND') return 'The configured database does not exist.';
    if (code === 'DATABASE_CONNECTION_REFUSED' || code === 'DATABASE_HOST_NOT_FOUND') return 'The database host could not be reached.';
    return 'Database initialization failed. Check the health endpoint for the diagnostic code and restart the Node.js application.';
}
const ACTIVE_SESSION_TTL_MS = 90000;
const activeSessions = new Map();

const MODULE_KEYS = [
    'dashboard',
    'banners',
    'online_admissions',
    'notifications',
    'families',
    'students',
    'student_scheduling',
    'teachers',
    'teacher_scheduling',
    'staff',
    'classes',
    'set_fee',
    'fees',
    'fee_challan',
    'remaining_charges',
    'payment_history',
    'annual_charges',
    'teacher_salaries',
    'bills',
    'student_attendance',
    'teacher_attendance',
    'student_attendance_report',
    'teacher_attendance_report',
    'messages',
    'special_notices',
    'exams',
    'revenue',
    'settings',
    'permissions',
    'branch_registration',
    'aboutme',
    'student_portal',
    'teacher_portal'
];
const ACCESS_LEVELS = ['none', 'view', 'edit', 'manage'];
const ALLOWED_HOME_PAGES = new Set([
    'dashboard.html',
    'students.html',
    'teachers.html',
    'staff.html',
    'classes.html',
    'fees.html',
    'set_fees.html',
    'fee_challan.html',
    'teacher_salaries.html',
    'student_attendance.html',
    'teacher_attendance.html',
    'student_attendance_report.html',
    'teacher_attendance_report.html',
    'notifications.html',
    'messages.html',
    'special_notices.html',
    'exams.html',
    'revenue.html',
    'settings.html',
    'permissions.html',
    'branch_registration.html',
    'aboutme.html',
    'student_portal.html',
    'teacher_portal.html'
]);

function buildModuleSet(defaultAccess = 'none', overrides = {}) {
    const acc = MODULE_KEYS.reduce((next, key) => {
        const requested = overrides[key];
        next[key] = ACCESS_LEVELS.includes(requested) ? requested : defaultAccess;
        return next;
    }, {});
    Object.entries(overrides || {}).forEach(([key, value]) => {
        if (!acc[key] && ACCESS_LEVELS.includes(value)) acc[key] = value;
    });
    return acc;
}

const defaultPermissions = {
    loginAccess: {
        admin: true,
        principal: true,
        branch: true,
        teacher: true,
        student: true,
        staff: true
    },
    roleGroups: {
        Admin: 'admin',
        Principal: 'admin',
        Branch: 'computer_operator',
        Teacher: 'teacher',
        Student: 'computer_operator',
        Staff: 'office_assistant'
    },
    groups: {
        superadmin: {
            name: 'Superadmin',
            homePage: 'dashboard.html',
            permissions: buildModuleSet('manage')
        },
        admin: {
            name: 'Admin',
            homePage: 'dashboard.html',
            permissions: buildModuleSet('manage')
        },
        computer_operator: {
            name: 'Computer Operator',
            homePage: 'dashboard.html',
            permissions: buildModuleSet('none', {
                dashboard: 'view',
                students: 'manage',
                teachers: 'view',
                staff: 'view',
                classes: 'view',
                fees: 'view',
                fee_challan: 'manage',
                student_attendance: 'edit',
                exams: 'view',
                notifications: 'view',
                messages: 'view',
                aboutme: 'view'
            })
        },
        teacher: {
            name: 'Teacher',
            homePage: 'teacher_portal.html',
            permissions: buildModuleSet('none', {
                dashboard: 'view',
                students: 'view',
                classes: 'view',
                student_scheduling: 'edit',
                student_attendance: 'edit',
                student_attendance_report: 'view',
                teacher_scheduling: 'view',
                messages: 'edit',
                special_notices: 'view',
                aboutme: 'view'
            })
        },
        accountant: {
            name: 'Accountant',
            homePage: 'fees.html',
            permissions: buildModuleSet('none', {
                dashboard: 'view',
                students: 'view',
                set_fee: 'edit',
                fees: 'manage',
                fee_challan: 'manage',
                remaining_charges: 'manage',
                payment_history: 'manage',
                annual_charges: 'manage',
                revenue: 'manage',
                teacher_salaries: 'edit',
                bills: 'manage',
                messages: 'view',
                aboutme: 'view'
            })
        },
        office_assistant: {
            name: 'Office Assistant',
            homePage: 'dashboard.html',
            permissions: buildModuleSet('none', {
                dashboard: 'view',
                online_admissions: 'edit',
                students: 'edit',
                teachers: 'view',
                staff: 'view',
                classes: 'view',
                families: 'edit',
                notifications: 'edit',
                messages: 'edit',
                special_notices: 'view',
                aboutme: 'view'
            })
        }
    }
};

function normalizePermissionsConfig(input = {}) {
    const raw = input && typeof input === 'object' ? input : {};
    const groupsInput = raw.groups && typeof raw.groups === 'object' ? raw.groups : {};
    const customModules = Array.isArray(raw.customModules) ? raw.customModules : [];
    const allowedHomePages = new Set(ALLOWED_HOME_PAGES);
    customModules.forEach((module) => {
        if (module && module.page) allowedHomePages.add(String(module.page));
    });
    const groups = Object.entries({
        ...defaultPermissions.groups,
        ...groupsInput
    }).reduce((acc, [key, groupValue]) => {
        const baseGroup = defaultPermissions.groups[key] || {
            name: key,
            homePage: 'dashboard.html',
            permissions: buildModuleSet('none'),
            actionPermissions: undefined
        };
        const nextGroup = groupValue && typeof groupValue === 'object' ? groupValue : {};
        const requestedHomePage = String(nextGroup.homePage || baseGroup.homePage || 'dashboard.html');
        const actionPermissions = nextGroup.actionPermissions && typeof nextGroup.actionPermissions === 'object'
            ? nextGroup.actionPermissions
            : (baseGroup.actionPermissions && typeof baseGroup.actionPermissions === 'object' ? baseGroup.actionPermissions : undefined);
        acc[key] = {
            name: String(nextGroup.name || baseGroup.name || key),
            homePage: allowedHomePages.has(requestedHomePage) ? requestedHomePage : 'dashboard.html',
            permissions: buildModuleSet('none', {
                ...baseGroup.permissions,
                ...(nextGroup.permissions || {})
            }),
            ...(actionPermissions ? { actionPermissions } : {})
        };
        return acc;
    }, {});

    return {
        loginAccess: {
            ...defaultPermissions.loginAccess,
            ...(raw.loginAccess || {}),
            admin: true,
            teacher: true,
            staff: true
        },
        roleGroups: {
            ...defaultPermissions.roleGroups,
            ...(raw.roleGroups || {}),
            Admin: 'admin',
            Teacher: 'teacher',
            Staff: 'office_assistant'
        },
        customModules,
        groups
    };
}

function isPasswordHash(value) {
    return typeof value === 'string' && /^\$2[aby]\$/.test(value);
}

function normalizeOptionalEmail(value) {
    const normalized = String(value || '').trim().toLowerCase();
    return normalized || null;
}

async function ensureUniqueTeacherIdentity(Teacher, User, item) {
    const teacherId = item.id || null;
    const normalizedEmail = normalizeOptionalEmail(item.email);
    const normalizedUsername = String(item.username || '').trim();

    if (!normalizedUsername) {
        throw new Error('Teacher username is required.');
    }

    const usernameConflict = await Teacher.findOne({
        where: {
            username: normalizedUsername,
            ...(teacherId ? { id: { [Op.ne]: teacherId } } : {})
        }
    });

    if (usernameConflict) {
        throw new Error('This teacher username is already assigned to another teacher.');
    }

    const userUsernameConflict = await User.findOne({
        where: {
            username: normalizedUsername,
            ...(teacherId ? { profileId: { [Op.ne]: teacherId } } : {})
        }
    });

    if (userUsernameConflict) {
        throw new Error('This username is already used by another account.');
    }

    if (normalizedEmail) {
        const emailConflict = await Teacher.findOne({
            where: {
                email: normalizedEmail,
                ...(teacherId ? { id: { [Op.ne]: teacherId } } : {})
            }
        });

        if (emailConflict) {
            throw new Error('This teacher email is already assigned to another teacher.');
        }

        const userEmailConflict = await User.findOne({
            where: {
                email: normalizedEmail,
                ...(teacherId ? { profileId: { [Op.ne]: teacherId } } : {})
            }
        });

        if (userEmailConflict) {
            throw new Error('This email is already used by another account.');
        }
    }
}

async function ensureUniqueStudentIdentity(Student, User, item) {
    const studentId = item.id || null;
    const normalizedEmail = normalizeOptionalEmail(item.email);
    const normalizedUsername = String(item.username || '').trim();

    if (normalizedUsername) {
        const usernameConflict = await Student.findOne({
            where: {
                username: normalizedUsername,
                ...(studentId ? { id: { [Op.ne]: studentId } } : {})
            }
        });

        if (usernameConflict) {
            throw new Error('This student username is already assigned to another student.');
        }

        const userUsernameConflict = await User.findOne({
            where: {
                username: normalizedUsername,
                ...(studentId ? { profileId: { [Op.ne]: studentId } } : {})
            }
        });

        if (userUsernameConflict) {
            throw new Error('This username is already used by another account.');
        }
    }

    if (normalizedEmail) {
        const emailConflict = await Student.findOne({
            where: {
                email: normalizedEmail,
                ...(studentId ? { id: { [Op.ne]: studentId } } : {})
            }
        });

        if (emailConflict) {
            throw new Error('This student email is already assigned to another student.');
        }

        const userEmailConflict = await User.findOne({
            where: {
                email: normalizedEmail,
                ...(studentId ? { profileId: { [Op.ne]: studentId } } : {})
            }
        });

        if (userEmailConflict) {
            throw new Error('This email is already used by another account.');
        }
    }
}

function isLocalDbHost(hostname) {
    const host = String(hostname || '').toLowerCase();
    return host === 'localhost' || host === '127.0.0.1' || host === '::1';
}

function shouldAutoCreateDatabase(hostname) {
    const explicit = String(process.env.AUTO_CREATE_DB || '').trim().toLowerCase();
    if (explicit === 'true') return true;
    if (explicit === 'false') return false;
    return isLocalDbHost(hostname);
}

async function initializeDatabase() {
    const dbHost = process.env.DB_HOST || 'localhost';
    const dbPort = Number(process.env.DB_PORT || 3306);
    const dbName = process.env.DB_NAME || 'school_system';

    if (!shouldAutoCreateDatabase(dbHost)) {
        console.log('Skipping CREATE DATABASE on non-local/shared hosting.');
        return;
    }

    try {
        const connection = await mysql.createConnection({
            host: dbHost,
            port: dbPort,
            user: process.env.DB_USER || 'root',
            password: process.env.DB_PASSWORD || ''
        });

        await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\`;`);
        await connection.end();
    } catch (err) {
        console.warn('Database initialization warning:', err.message);
    }
}

function authenticateToken(req, res, next) {
    const authHeader = req.headers.authorization || '';
    const cookieToken = String(req.headers.cookie || '')
        .split(';')
        .map((part) => part.trim())
        .find((part) => part.startsWith('eduCore_token='))
        ?.slice('eduCore_token='.length);
    const token = authHeader.startsWith('Bearer ')
        ? authHeader.slice(7)
        : String(req.headers['x-auth-token'] || '').trim() || (cookieToken ? decodeURIComponent(cookieToken) : null);

    if (!token) {
        return res.status(401).json({ success: false, message: 'Authentication token required.' });
    }

    try {
        req.user = jwt.verify(token, JWT_SECRET);

        pruneActiveSessions();
        const sessionId = String(req.user?.sessionId || '').trim();
        const allowIfInactive = req.path === '/api/session/end';
        if (sessionId && !activeSessions.has(sessionId) && !allowIfInactive) {
            restoreActiveSessionFromToken(req);
        }

        next();
    } catch (error) {
        return res.status(401).json({ success: false, message: 'Invalid or expired token.' });
    }
}

function setAuthenticationCookie(req, res, token) {
    const forwardedProtocol = String(req.get('x-forwarded-proto') || '').toLowerCase();
    res.cookie('eduCore_token', token, {
        httpOnly: true,
        secure: req.secure || forwardedProtocol === 'https',
        sameSite: 'lax',
        path: '/',
        maxAge: 24 * 60 * 60 * 1000
    });
}

function restoreActiveSessionFromToken(req) {
    const sessionId = String(req.user?.sessionId || '').trim();
    if (!sessionId) return;

    const role = req.user?.role || 'User';
    const userId = req.user?.id || req.user?.username || 'unknown';
    registerActiveSession(req, sessionId, {
        id: userId,
        fullName: req.user?.fullName || role,
        role,
        username: req.user?.username || String(userId),
        campusName: req.user?.campusName || ''
    });
}

function pruneActiveSessions() {
    const now = Date.now();
    activeSessions.forEach((session, sessionId) => {
        if (!session.lastSeen || now - session.lastSeen > ACTIVE_SESSION_TTL_MS) {
            activeSessions.delete(sessionId);
        }
    });
}

function createSessionId(role, id) {
    return `${String(role || 'user').toLowerCase()}_${String(id || '0')}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

function registerActiveSession(req, sessionId, user) {
    if (!sessionId || !user) return;

    activeSessions.set(sessionId, {
        sessionId,
        userId: String(user.id || ''),
        username: user.username || '',
        fullName: user.fullName || '',
        role: user.role || '',
        campusName: user.campusName || '',
        loginAt: Date.now(),
        lastSeen: Date.now(),
        ip: req.ip || req.socket?.remoteAddress || '',
        userAgent: req.get('user-agent') || ''
    });
}

function buildActiveSessionsSummary() {
    pruneActiveSessions();
    const sessions = Array.from(activeSessions.values())
        .sort((a, b) => Number(b.lastSeen || 0) - Number(a.lastSeen || 0))
        .map((session) => ({
            ...session,
            loginAt: new Date(session.loginAt).toISOString(),
            lastSeen: new Date(session.lastSeen).toISOString()
        }));
    const byRole = sessions.reduce((acc, session) => {
        const role = session.role || 'Unknown';
        acc[role] = (acc[role] || 0) + 1;
        return acc;
    }, {});
    const uniqueUsers = new Set(sessions.map((session) => `${session.role}:${session.userId || session.username}`));
    const uniqueSessionMap = new Map();
    sessions.forEach((session) => {
        const key = `${session.role}:${session.userId || session.username}`;
        if (!uniqueSessionMap.has(key)) {
            uniqueSessionMap.set(key, session);
        }
    });
    const uniqueSessions = Array.from(uniqueSessionMap.values());

    return {
        success: true,
        totalActiveLogins: sessions.length,
        totalActiveSessions: sessions.length,
        uniqueActiveUsers: uniqueUsers.size,
        byRole,
        sessions,
        uniqueSessions
    };
}

function safeStoreName(name = '') {
    return String(name || '').replace(/[^a-z0-9_-]/gi, '_').toLowerCase();
}

function mobileStorePath(storeName) {
    return path.join(MOBILE_API_STORE_DIR, `${safeStoreName(storeName)}.json`);
}

function readMobileStore(storeName) {
    try {
        const filePath = mobileStorePath(storeName);
        if (!fs.existsSync(filePath)) return [];
        const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        return Array.isArray(parsed) ? parsed : [];
    } catch (_error) {
        return [];
    }
}

function writeMobileStore(storeName, records = []) {
    const normalized = Array.isArray(records) ? records : [];
    fs.writeFileSync(mobileStorePath(storeName), JSON.stringify(normalized, null, 2), 'utf8');
    return normalized;
}

function getMobileRecordsPayload(recordsKey, storeName) {
    const records = readMobileStore(storeName);
    return { success: true, [recordsKey]: records };
}

function normalizeMobileRecord(payload = {}, prefix = 'REC') {
    const raw = payload && typeof payload === 'object' ? payload : {};
    const id = String(raw.id || `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`).trim();
    const now = new Date().toISOString();
    return {
        ...raw,
        id,
        createdAt: raw.createdAt || now,
        updatedAt: now
    };
}

function upsertMobileRecord(storeName, payload, prefix) {
    const records = readMobileStore(storeName);
    const record = normalizeMobileRecord(payload, prefix);
    const index = records.findIndex((item) => String(item.id) === String(record.id));
    if (index >= 0) {
        records[index] = { ...records[index], ...record };
    } else {
        records.unshift(record);
    }
    return { record, records: writeMobileStore(storeName, records) };
}

function deleteMobileRecord(storeName, id) {
    const records = readMobileStore(storeName);
    const nextRecords = records.filter((item) => String(item.id) !== String(id));
    return writeMobileStore(storeName, nextRecords);
}

function registerMobileCollectionRoutes({ route, storeName, recordsKey, itemKey, prefix, socketEvent }) {
    app.get(`/api/${route}`, (req, res) => {
        res.json(getMobileRecordsPayload(recordsKey, storeName));
    });

    app.post(`/api/${route}`, (req, res) => {
        const { record, records } = upsertMobileRecord(storeName, req.body || {}, prefix);
        if (socketEvent) io.emit(socketEvent, records);
        res.json({ success: true, [itemKey]: record, [recordsKey]: records });
    });

    app.delete(`/api/${route}/:id`, (req, res) => {
        const records = deleteMobileRecord(storeName, req.params.id);
        if (socketEvent) io.emit(socketEvent, records);
        res.json({ success: true, deleted: true, [recordsKey]: records });
    });
}

function canManageActiveSessions(user = {}) {
    const role = String(user?.role || '').trim().toLowerCase();
    return role === 'admin'
        || role === 'superadmin'
        || role === 'super admin'
        || role === 'system administrator'
        || role === 'system_admin';
}

function readPermissions() {
    try {
        if (!fs.existsSync(PERMISSIONS_FILE)) {
            return writePermissions(defaultPermissions);
        }

        const raw = fs.readFileSync(PERMISSIONS_FILE, 'utf8');
        const saved = JSON.parse(raw);

        return normalizePermissionsConfig(saved);
    } catch (error) {
        return defaultPermissions;
    }
}

function writePermissions(data) {
    const nextPermissions = normalizePermissionsConfig(data);

    fs.writeFileSync(PERMISSIONS_FILE, JSON.stringify(nextPermissions, null, 2), 'utf8');
    return nextPermissions;
}

function loadDetailedPermissions() {
    try {
        if (!fs.existsSync(DETAILED_PERMISSIONS_FILE)) {
            return { system: {}, designations: {} };
        }

        const raw = fs.readFileSync(DETAILED_PERMISSIONS_FILE, 'utf8');
        const parsed = raw ? JSON.parse(raw) : {};
        return parsed && typeof parsed === 'object' ? parsed : { system: {}, designations: {} };
    } catch (error) {
        console.warn('Failed to load detailed permissions:', error.message);
        return { system: {}, designations: {} };
    }
}

function saveDetailedPermissions(data) {
    const payload = data && typeof data === 'object' ? data : {};
    fs.writeFileSync(DETAILED_PERMISSIONS_FILE, JSON.stringify(payload, null, 2), 'utf8');
    return payload;
}

function normalizeDesignationKey(value) {
    const raw = String(value || '').trim().toLowerCase();
    if (!raw) return '';
    return raw
        .replace(/[\s-]+/g, '_')
        .replace(/[^a-z0-9_]/g, '')
        .replace(/^_+|_+$/g, '');
}

function checkDesignationActionPermission(designationKey, moduleKey, actionKey) {
    const detailed = loadDetailedPermissions();
    const designation = detailed?.designations?.[designationKey];
    const allowed = designation?.actionPermissions?.[moduleKey]?.[actionKey] === true;
    return allowed;
}

async function resolveUserDesignationKey(user = {}) {
    if (!sequelize) return '';
    const role = String(user?.role || '').trim();
    const id = String(user?.id || '').trim();
    if (!id) return '';

    try {
        if (role === 'Teacher') {
            const teacher = await sequelize.models.Teacher.findByPk(id);
            return normalizeDesignationKey(teacher?.designation || 'teacher');
        }
        if (role === 'Staff') {
            const staff = await sequelize.models.Staff.findByPk(id);
            return normalizeDesignationKey(staff?.designation || 'staff');
        }
        return '';
    } catch (error) {
        console.warn('Failed to resolve user designation:', error.message);
        return '';
    }
}

async function enforceActionPermission(req, res, moduleKey, actionKey) {
    const role = String(req.user?.role || '').trim();

    if (role === 'Principal') return true;
    if (role === 'Admin' && moduleKey === 'permissions') return true;
    if (role === 'Branch') {
        res.status(403).json({ success: false, message: 'Branch access denied.' });
        return false;
    }
    if (role === 'Student') {
        res.status(403).json({ success: false, message: 'Student access denied.' });
        return false;
    }

    if (role === 'Admin' || role === 'Teacher' || role === 'Staff') {
        const permissions = readPermissions();
        const designationKey = role === 'Staff' ? await resolveUserDesignationKey(req.user) : '';
        const groupKey = role === 'Admin'
            ? 'admin'
            : (role === 'Teacher' ? 'teacher' : (designationKey || permissions.roleGroups?.[role] || ''));
        const group = permissions.groups?.[groupKey];
        if (!group) {
            res.status(403).json({ success: false, message: 'Permission profile is not configured. Ask admin to assign one.' });
            return false;
        }

        const explicitPermission = group.actionPermissions?.[moduleKey]?.[actionKey];
        const accessLevel = String(group.permissions?.[moduleKey] || 'none').toLowerCase();
        const allowed = typeof explicitPermission === 'boolean'
            ? explicitPermission
            : (
                actionKey === 'view'
                    ? accessLevel !== 'none'
                    : (actionKey === 'add' || actionKey === 'edit')
                        ? accessLevel === 'edit' || accessLevel === 'manage'
                        : accessLevel === 'manage'
            );
        if (!allowed) {
            res.status(403).json({
                success: false,
                message: `Permission denied: ${group.name || groupKey} cannot ${actionKey} in ${moduleKey}.`
            });
            return false;
        }

        return true;
    }

    // Keep legacy behavior for other roles (e.g., Branch) unless explicitly restricted.
    return true;
}

function getDefaultAdminCredentials() {
    return require('../api/_lib/adminConfig').getAdminCredentialsFromEnv();
}

function readAdminCredentials() {
    const defaults = getDefaultAdminCredentials();
    try {
        if (!fs.existsSync(ADMIN_CREDENTIALS_FILE)) {
            return defaults;
        }

        const raw = fs.readFileSync(ADMIN_CREDENTIALS_FILE, 'utf8');
        const parsed = JSON.parse(raw);
        const username = String(parsed?.username || '').trim();
        const password = String(parsed?.password || '');

        if (!username || !password) {
            return defaults;
        }

        return { username, password };
    } catch (_error) {
        return defaults;
    }
}

function writeAdminCredentials(data = {}) {
    const username = String(data.username || '').trim();
    const password = String(data.password || '');

    if (!username) {
        const error = new Error('Admin username is required.');
        error.statusCode = 400;
        throw error;
    }

    if (!password) {
        const error = new Error('Admin password is required.');
        error.statusCode = 400;
        throw error;
    }

    const next = { username, password };
    fs.writeFileSync(ADMIN_CREDENTIALS_FILE, JSON.stringify(next, null, 2), 'utf8');
    return next;
}

function verifyAdminAccessToken(req) {
    const authHeader = req.headers.authorization || '';
    const cookieToken = String(req.headers.cookie || '')
        .split(';')
        .map((part) => part.trim())
        .find((part) => part.startsWith('eduCore_token='))
        ?.slice('eduCore_token='.length);
    const token = authHeader.startsWith('Bearer ')
        ? authHeader.slice(7)
        : String(req.headers['x-auth-token'] || '').trim() || (cookieToken ? decodeURIComponent(cookieToken) : '');

    if (!token) {
        const error = new Error('Admin access required.');
        error.statusCode = 401;
        throw error;
    }

    let user = null;
    try {
        user = jwt.verify(token, JWT_SECRET);
    } catch (_error) {
        const error = new Error('Admin access required.');
        error.statusCode = 401;
        throw error;
    }

    if (user.role !== 'Admin') {
        const error = new Error('Admin access required.');
        error.statusCode = 403;
        throw error;
    }

    return user;
}

app.get('/api/permissions', (req, res) => {
    res.json(readPermissions());
});

app.post('/api/permissions', (req, res) => {
    try {
        verifyAdminAccessToken(req);
        const saved = writePermissions(req.body || {});
        res.json({ success: true, permissions: saved });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Failed to save permissions.' });
    }
});

app.get('/api/designation-permissions', authenticateToken, async (req, res) => {
    try {
        const designationParam = req.query?.designation;
        const actionParam = req.query?.action;
        const designationKey = normalizeDesignationKey(designationParam);

        if (designationKey && actionParam) {
            const [moduleKeyRaw, actionKeyRaw] = String(actionParam).split('.');
            const moduleKey = String(moduleKeyRaw || '').trim();
            const actionKey = String(actionKeyRaw || '').trim();
            const allowed = moduleKey && actionKey
                ? checkDesignationActionPermission(designationKey, moduleKey, actionKey)
                : false;
            return res.json({ allowed });
        }

        if (designationKey) {
            const detailed = loadDetailedPermissions();
            const perms = detailed?.designations?.[designationKey] || null;
            return res.json(perms || { key: designationKey, name: designationKey, description: '', actionPermissions: {} });
        }

        verifyAdminAccessToken(req);
        const detailed = loadDetailedPermissions();
        const designations = Object.entries(detailed?.designations || {}).map(([key, value]) => ({
            key,
            name: value?.name || key,
            description: value?.description || ''
        }));

        return res.json({
            designations,
            permissions: detailed?.designations || {}
        });
    } catch (error) {
        return res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Failed to load designation permissions.' });
    }
});

app.post('/api/designation-permissions', authenticateToken, (req, res) => {
    try {
        verifyAdminAccessToken(req);
        const body = req.body && typeof req.body === 'object' ? req.body : {};
        const incomingDesignations = body.permissions && typeof body.permissions === 'object'
            ? body.permissions
            : (body.designations && typeof body.designations === 'object' ? body.designations : null);

        const existing = loadDetailedPermissions();
        const next = incomingDesignations
            ? { ...(existing || {}), designations: incomingDesignations }
            : body;

        const saved = saveDetailedPermissions(next);
        const designations = Object.entries(saved?.designations || {}).map(([key, value]) => ({
            key,
            name: value?.name || key,
            description: value?.description || ''
        }));

        res.json({
            success: true,
            designations,
            permissions: saved?.designations || {}
        });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Failed to save designation permissions.' });
    }
});

app.get('/api/admin-credentials', (req, res) => {
    try {
        verifyAdminAccessToken(req);
        const credentials = readAdminCredentials();
        res.json({ success: true, credentials: { username: credentials.username } });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Failed to load admin credentials.' });
    }
});

app.post('/api/admin-credentials', (req, res) => {
    try {
        verifyAdminAccessToken(req);
        const current = readAdminCredentials();
        const nextUsername = String(req.body?.username || '').trim();
        const hasPasswordChange = Object.prototype.hasOwnProperty.call(req.body || {}, 'password');
        const nextPassword = hasPasswordChange ? String(req.body?.password || '') : '';
        if (hasPasswordChange) {
            const currentPassword = String(req.body?.currentPassword || '');
            if (!currentPassword) {
                return res.status(400).json({ success: false, message: 'Current password is required.' });
            }
            if (currentPassword !== current.password) {
                return res.status(401).json({ success: false, message: 'Current password is incorrect.' });
            }
            const confirmPassword = String(req.body?.confirmPassword || '');
            if (!nextPassword) {
                return res.status(400).json({ success: false, message: 'New password is required.' });
            }
            if (nextPassword !== confirmPassword) {
                return res.status(400).json({ success: false, message: 'New password and confirm password do not match.' });
            }
            if (nextPassword.length < 6) {
                return res.status(400).json({ success: false, message: 'New password must be at least 6 characters.' });
            }
        }
        const saved = writeAdminCredentials({
            username: nextUsername || current.username,
            password: hasPasswordChange ? nextPassword : current.password
        });
        res.json({ success: true, credentials: { username: saved.username } });
    } catch (error) {
        res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Failed to save admin credentials.' });
    }
});

function normalizeDateSheetPayload(data = {}) {
    const raw = data && typeof data === 'object' ? data : {};
    const scheduleRows = Array.isArray(raw.scheduleRows)
        ? raw.scheduleRows.map((row) => ({
            subject: String(row.subject || '').trim(),
            className: String(row.className || '').trim(),
            examDate: String(row.examDate || '').trim(),
            startTime: String(row.startTime || '').trim(),
            endTime: String(row.endTime || '').trim()
        })).filter((row) => row.subject || row.className || row.examDate || row.startTime || row.endTime)
        : [];

    return {
        dateSheetSchoolName: String(raw.dateSheetSchoolName || '').trim(),
        dateSheetExamTitle: String(raw.dateSheetExamTitle || '').trim(),
        dateSheetSession: String(raw.dateSheetSession || '').trim(),
        dateSheetClassGroup: String(raw.dateSheetClassGroup || '').trim(),
        dateSheetCampus: String(raw.dateSheetCampus || '').trim(),
        dateSheetDefaultStart: String(raw.dateSheetDefaultStart || '').trim(),
        dateSheetInstructions: String(raw.dateSheetInstructions || '').trim(),
        scheduleRows,
        status: ['executed', 'hidden'].includes(raw.status) ? raw.status : 'draft',
        executedAt: raw.executedAt || (raw.status === 'executed' ? new Date().toISOString() : null),
        hiddenAt: raw.status === 'hidden' ? (raw.hiddenAt || new Date().toISOString()) : null,
        updatedAt: new Date().toISOString()
    };
}

function readDateSheet() {
    try {
        if (!fs.existsSync(DATE_SHEET_FILE)) return null;
        const saved = JSON.parse(fs.readFileSync(DATE_SHEET_FILE, 'utf8'));
        return normalizeDateSheetPayload(saved);
    } catch (error) {
        return null;
    }
}

function writeDateSheet(data) {
    const normalized = normalizeDateSheetPayload(data);
    fs.writeFileSync(DATE_SHEET_FILE, JSON.stringify(normalized, null, 2), 'utf8');
    return normalized;
}

app.get('/api/date-sheet', (req, res) => {
    res.json({ success: true, dateSheet: readDateSheet() });
});

app.post('/api/date-sheet', (req, res) => {
    try {
        const saved = writeDateSheet(req.body || {});
        io.emit('date_sheet_update', saved);
        res.json({ success: true, dateSheet: saved });
    } catch (error) {
        res.status(500).json({ success: false, message: 'Date sheet could not be executed.' });
    }
});

app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const adminCredentials = readAdminCredentials();
        const adminUsername = adminCredentials.username;
        const adminPass = adminCredentials.password;

        if (username === adminUsername && password === adminPass) {
            const permissions = readPermissions();
            const groupKey = permissions.roleGroups.Admin || 'admin';
            const sessionId = createSessionId('Admin', 'admin');
            const token = jwt.sign({ id: 'admin', role: 'Admin', sessionId }, JWT_SECRET, { expiresIn: '1d' });
            const user = { id: 'admin', fullName: 'Administrator', role: 'Admin', username: adminUsername, groupKey };
            registerActiveSession(req, sessionId, user);
            setAuthenticationCookie(req, res, token);
            return res.json({
                success: true,
                token,
                sessionId,
                permissions,
                user
            });
        }

        if (username === PRINCIPAL_USERNAME && password === PRINCIPAL_PASSWORD) {
            const permissions = readPermissions();
            if (permissions.loginAccess.principal === false) {
                return res.status(403).json({ success: false, message: 'Principal login is currently disabled by admin.' });
            }
            const groupKey = permissions.roleGroups.Principal || 'principal';
            const sessionId = createSessionId('Principal', 'principal');
            const token = jwt.sign({ id: 'principal', role: 'Principal', sessionId }, JWT_SECRET, { expiresIn: '1d' });
            const user = { id: 'principal', fullName: 'Principal', role: 'Principal', username: PRINCIPAL_USERNAME, groupKey };
            registerActiveSession(req, sessionId, user);
            setAuthenticationCookie(req, res, token);
            return res.json({
                success: true,
                token,
                sessionId,
                permissions,
                user
            });
        }

        if (!sequelize) {
            return res.status(503).json({ success: false, message: 'Database is offline. Only Admin can log in.' });
        }

        const normalizedIdentity = String(username || '').trim();
        const userWhere = {
            [Op.or]: [
                { username: normalizedIdentity }
            ]
        };

        if (normalizedIdentity.includes('@')) {
            userWhere[Op.or].push({ email: normalizedIdentity.toLowerCase() });
        }

        const User = sequelize.models.User;
        const Student = sequelize.models.Student;
        const Teacher = sequelize.models.Teacher;
        const user = await User.findOne({ where: userWhere });

        if (user) {
            const isMatch = await bcrypt.compare(password, user.password);

            if (isMatch) {
                const permissions = readPermissions();
                let profileName = user.fullName;
                let designationKey = '';

                if (user.role === 'Student') {
                    const student = await Student.findByPk(user.profileId);
                    profileName = student?.fullName || profileName;
                } else if (user.role === 'Teacher') {
                    const teacher = await Teacher.findByPk(user.profileId);
                    profileName = teacher?.fullName || profileName;
                    designationKey = normalizeDesignationKey(teacher?.designation || 'teacher');
                } else if (user.role === 'Staff') {
                    const staff = await sequelize.models.Staff.findByPk(user.profileId);
                    profileName = staff?.fullName || profileName;
                    designationKey = normalizeDesignationKey(staff?.designation || 'staff');
                }

                const effectiveRole = user.role === 'Teacher'
                    ? (designationKey === 'admin' ? 'Admin' : (designationKey === 'accountant' ? 'Staff' : (designationKey === 'principal' ? 'Principal' : 'Teacher')))
                    : user.role;
                const roleKey = String(effectiveRole || '').toLowerCase();
                if (permissions.loginAccess[roleKey] === false) {
                    return res.status(403).json({ success: false, message: `${effectiveRole} login is currently disabled by admin.` });
                }

                const sessionId = createSessionId(effectiveRole, user.profileId);
                const token = jwt.sign({ id: user.profileId, role: effectiveRole, campusName: user.campusName || '', sessionId }, JWT_SECRET, { expiresIn: '1d' });
                const responseUser = {
                    id: user.profileId,
                    fullName: profileName,
                    role: effectiveRole,
                    username: user.username,
                    campusName: user.campusName || '',
                    groupKey: effectiveRole === 'Teacher'
                        ? 'teacher'
                        : (effectiveRole === 'Staff' && designationKey
                            ? designationKey
                            : (user.groupKey || permissions.roleGroups[effectiveRole] || roleKey)),
                    ...(designationKey ? { designation: designationKey } : {})
                };
                registerActiveSession(req, sessionId, responseUser);
                setAuthenticationCookie(req, res, token);
                return res.json({
                    success: true,
                    token,
                    sessionId,
                    permissions,
                    user: responseUser
                });
            }
        }

        return res.status(401).json({ success: false, message: 'Invalid credentials' });
    } catch (err) {
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/session/heartbeat', authenticateToken, (req, res) => {
    const sessionId = req.user.sessionId;
    if (!sessionId) {
        return res.status(400).json({ success: false, message: 'Session id missing.' });
    }

    const existing = activeSessions.get(sessionId);
    activeSessions.set(sessionId, {
        ...(existing || {}),
        sessionId,
        userId: String(req.user.id || existing?.userId || ''),
        role: req.user.role || existing?.role || '',
        campusName: req.user.campusName || existing?.campusName || '',
        loginAt: existing?.loginAt || Date.now(),
        lastSeen: Date.now(),
        ip: req.ip || req.socket?.remoteAddress || existing?.ip || '',
        userAgent: req.get('user-agent') || existing?.userAgent || ''
    });

    res.json({ success: true });
});

app.post('/api/session/end', authenticateToken, (req, res) => {
    if (req.user.sessionId) {
        activeSessions.delete(req.user.sessionId);
    }

    res.clearCookie('eduCore_token', { path: '/' });
    res.json({ success: true });
});

app.get('/api/active-sessions', authenticateToken, (req, res) => {
    if (!canManageActiveSessions(req.user)) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }

    res.json(buildActiveSessionsSummary());
});

app.delete('/api/active-sessions/:sessionId', authenticateToken, (req, res) => {
    if (!canManageActiveSessions(req.user)) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }

    const targetSessionId = decodeURIComponent(String(req.params.sessionId || '').trim());
    if (!targetSessionId) {
        return res.status(400).json({ success: false, message: 'Session id is required.' });
    }

    const hadSession = activeSessions.delete(targetSessionId);
    if (hadSession) {
        io.emit('session_forced_logout', { sessionId: targetSessionId });
    }
    return res.json({
        success: true,
        message: hadSession ? 'Session has been logged out.' : 'Session was already inactive.'
    });
});

app.post('/api/active-sessions/logout', authenticateToken, (req, res) => {
    if (!canManageActiveSessions(req.user)) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }

    const targetSessionId = decodeURIComponent(String(req.body?.sessionId || '').trim());
    if (!targetSessionId) {
        return res.status(400).json({ success: false, message: 'Session id is required.' });
    }

    const hadSession = activeSessions.delete(targetSessionId);
    if (hadSession) {
        io.emit('session_forced_logout', { sessionId: targetSessionId });
    }
    return res.json({
        success: true,
        message: hadSession ? 'Session has been logged out.' : 'Session was already inactive.'
    });
});

app.get('/api/students', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const Student = sequelize.models.Student;
        await Student.sync();
        const students = await Student.findAll();
        res.json(students);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

function normalizeClassFeeRecords(records = []) {
    const input = Array.isArray(records) ? records : [];
    const byClass = new Map();

    input.forEach((record) => {
        const className = String(record?.className || record?.name || '').trim();
        if (!className) return;
        const key = className.toLowerCase().replace(/[-_]+/g, ' ').replace(/\s+/g, ' ');
        byClass.set(key, {
            id: record?.id || `CLASS-FEE-${key.replace(/[^a-z0-9]+/g, '-')}`,
            className,
            monthlyFee: Number(record?.monthlyFee || record?.amount || 0) || 0,
            annualCharges: Number(record?.annualCharges || record?.annualFee || 0) || 0,
            feeFrequency: String(record?.feeFrequency || 'Monthly').trim() || 'Monthly',
            feeMonth: String(record?.feeMonth || '').trim(),
            feeYear: String(record?.feeYear || '').trim(),
            sessionFrom: String(record?.sessionFrom || '').trim(),
            sessionTo: String(record?.sessionTo || '').trim(),
            updatedAtLabel: record?.updatedAtLabel || new Date().toLocaleString('en-GB')
        });
    });

    return Array.from(byClass.values());
}

function deriveClassFeesFromStudents(students = []) {
    const byClass = new Map();

    students.forEach((student) => {
        const className = String(student?.classGrade || '').trim();
        const monthlyFee = Number(String(student?.monthlyFee || student?.fee || 0).replace(/,/g, '')) || 0;
        if (!className || monthlyFee <= 0) return;

        const key = className.toLowerCase().replace(/[-_]+/g, ' ').replace(/\s+/g, ' ');
        if (byClass.has(key)) return;

        byClass.set(key, {
            id: key,
            className,
            monthlyFee,
            feeFrequency: String(student?.feeFrequency || 'Monthly').trim() || 'Monthly',
            updatedAtLabel: new Date().toLocaleString('en-GB')
        });
    });

    return Array.from(byClass.values()).sort((a, b) => a.className.localeCompare(b.className, undefined, { numeric: true, sensitivity: 'base' }));
}

async function syncClassFeeToDatabaseStudents(record, previousMonthlyFee = 0) {
    const targetClass = String(record?.className || '').trim().toLowerCase().replace(/[-_]+/g, ' ').replace(/\s+/g, ' ');
    if (!targetClass) return;
    const students = await sequelize.models.Student.findAll();
    for (const student of students) {
        const studentClass = String(student.classGrade || '').trim().toLowerCase().replace(/[-_]+/g, ' ').replace(/\s+/g, ' ');
        if (studentClass !== targetClass) continue;
        const studentFee = Number(student.monthlyFee || 0) || 0;
        const isCustom = student.monthlyFeeCustom === true;
        const isFree = student.freeStudy === true || Boolean(String(student.zeroFeeReason || '').trim());
        const followsClassDefault = studentFee <= 0 || (Number(previousMonthlyFee || 0) > 0 && studentFee === Number(previousMonthlyFee));
        if (isCustom || isFree || !followsClassDefault) continue;
        await student.update({ monthlyFee: String(record.monthlyFee || 0), feeFrequency: 'Monthly' });
    }
}

app.get('/api/class-fees', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline', classFees: [] });

    try {
        const rows = await sequelize.models.ClassFee.findAll({ order: [['className', 'ASC']] });
        const history = sequelize.models.ClassFeeHistory
            ? await sequelize.models.ClassFeeHistory.findAll({ order: [['updatedAt', 'DESC']] })
            : [];
        if (rows.length) {
            res.json({ success: true, classFees: rows, classFeeHistory: history });
            return;
        }

        const students = await sequelize.models.Student.findAll({
            attributes: ['classGrade', 'monthlyFee', 'feeFrequency'],
            order: [['classGrade', 'ASC']]
        });
        res.json({ success: true, classFees: deriveClassFeesFromStudents(students), classFeeHistory: history, source: 'students' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message, classFees: [] });
    }
});

app.post('/api/class-fees', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const ok = await enforceActionPermission(req, res, 'fees', 'edit');
        if (!ok) return;

        const ClassFee = sequelize.models.ClassFee;
        const ClassFeeHistory = sequelize.models.ClassFeeHistory;
        const records = normalizeClassFeeRecords(Array.isArray(req.body) ? req.body : [req.body]);
        if (!records.length) return res.status(400).json({ success: false, message: 'Class and fee details are required.' });
        if (records.some((record) => !record.sessionFrom || !record.sessionTo || record.sessionFrom > record.sessionTo)) {
            return res.status(400).json({ success: false, message: 'A valid session From and To is required.' });
        }
        for (const record of records) {
            const previous = await ClassFee.findByPk(record.id);
            await ClassFee.upsert(record);
            await ClassFeeHistory.create({
                ...record,
                id: `CLASS-FEE-HISTORY-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
            });
            await syncClassFeeToDatabaseStudents(record, previous?.monthlyFee || 0);
        }

        const allRecords = await ClassFee.findAll({ order: [['className', 'ASC']] });
        const history = await ClassFeeHistory.findAll({ order: [['updatedAt', 'DESC']] });
        io.emit('class_fees_update', allRecords);
        res.json({ success: true, classFees: allRecords, classFeeHistory: history });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.put('/api/class-fees/history/:id', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });
    try {
        const ok = await enforceActionPermission(req, res, 'fees', 'edit');
        if (!ok) return;
        const historyRecord = await sequelize.models.ClassFeeHistory.findByPk(String(req.params.id || ''));
        if (!historyRecord) return res.status(404).json({ success: false, message: 'Fee history record not found.' });
        const normalized = normalizeClassFeeRecords([{ ...historyRecord.toJSON(), ...(req.body || {}) }])[0];
        if (!normalized) return res.status(400).json({ success: false, message: 'Class and fee details are required.' });
        if (!normalized.sessionFrom || !normalized.sessionTo || normalized.sessionFrom > normalized.sessionTo) {
            return res.status(400).json({ success: false, message: 'A valid session From and To is required.' });
        }
        await historyRecord.update(normalized);
        const classFeeKey = normalized.className.toLowerCase().replace(/[-_]+/g, ' ').replace(/\s+/g, ' ');
        const currentClassFeeId = `CLASS-FEE-${classFeeKey.replace(/[^a-z0-9]+/g, '-')}`;
        const previous = await sequelize.models.ClassFee.findByPk(currentClassFeeId);
        await sequelize.models.ClassFee.upsert({
            ...normalized,
            id: currentClassFeeId
        });
        await syncClassFeeToDatabaseStudents(normalized, previous?.monthlyFee || 0);
        const classFees = await sequelize.models.ClassFee.findAll({ order: [['className', 'ASC']] });
        const classFeeHistory = await sequelize.models.ClassFeeHistory.findAll({ order: [['updatedAt', 'DESC']] });
        io.emit('class_fees_update', classFees);
        res.json({ success: true, classFees, classFeeHistory });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.delete('/api/class-fees/history/:id', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });
    try {
        const ok = await enforceActionPermission(req, res, 'fees', 'delete');
        if (!ok) return;
        const deleted = await sequelize.models.ClassFeeHistory.destroy({ where: { id: String(req.params.id || '') } });
        if (!deleted) return res.status(404).json({ success: false, message: 'Fee history record not found.' });
        const classFees = await sequelize.models.ClassFee.findAll({ order: [['className', 'ASC']] });
        const classFeeHistory = await sequelize.models.ClassFeeHistory.findAll({ order: [['updatedAt', 'DESC']] });
        res.json({ success: true, classFees, classFeeHistory });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

function formatStudentDiaryEntry(entry = {}) {
    const row = entry?.toJSON ? entry.toJSON() : entry;
    let file = row.file || null;
    if (typeof file === 'string' && file) {
        try {
            file = JSON.parse(file);
        } catch (_error) {
            file = null;
        }
    }

    return {
        ...row,
        file
    };
}

async function listStudentDiaryEntries() {
    const rows = await sequelize.models.StudentDiary.findAll({
        order: [['date', 'DESC'], ['updatedAt', 'DESC']]
    });
    return rows.map(formatStudentDiaryEntry);
}

function normalizeStudentDiaryPayload(payload = {}) {
    const now = new Date().toISOString();
    const title = String(payload.title || payload.subject || '').trim();
    const details = String(payload.details || payload.description || payload.homework || '').trim();
    const classGrade = String(payload.classGrade || payload.className || payload.class || '').trim();
    const date = String(payload.date || payload.diaryDate || '').trim();

    return {
        id: String(payload.id || `DIARY-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`),
        campusName: String(payload.campusName || '').trim(),
        classGrade,
        section: String(payload.section || payload.classSection || 'General').trim() || 'General',
        date,
        title,
        details,
        file: payload.file ? JSON.stringify(payload.file) : null,
        createdByRole: String(payload.createdByRole || 'Admin').trim(),
        createdByTeacherId: String(payload.createdByTeacherId || '').trim(),
        teacherId: String(payload.teacherId || '').trim(),
        teacherName: String(payload.teacherName || '').trim(),
        createdAtLabel: payload.createdAtLabel || now,
        createdAt: payload.createdAt || now,
        updatedAt: now
    };
}

app.get('/api/student-diary', async (_req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline', diary: [] });

    try {
        res.json({ success: true, diary: await listStudentDiaryEntries() });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message, diary: [] });
    }
});

app.post('/api/student-diary', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline', diary: [] });

    try {
        const record = normalizeStudentDiaryPayload(req.body || {});
        if (!record.classGrade || !record.date || !record.title || !record.details) {
            return res.status(400).json({ success: false, message: 'Class, date, subject, and diary details are required.', diary: await listStudentDiaryEntries() });
        }

        await sequelize.models.StudentDiary.upsert(record);
        const entry = await sequelize.models.StudentDiary.findByPk(record.id);
        const diary = await listStudentDiaryEntries();
        io.emit('student_diary_update', diary);
        res.json({ success: true, entry: formatStudentDiaryEntry(entry || record), diary });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message, diary: [] });
    }
});

async function deleteStudentDiaryById(req, res) {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline', diary: [] });

    try {
        const id = String(req.params.id || req.query.id || '').trim();
        if (!id) return res.status(400).json({ success: false, message: 'Diary id is required.', diary: await listStudentDiaryEntries() });

        await sequelize.models.StudentDiary.destroy({ where: { id } });
        const diary = await listStudentDiaryEntries();
        io.emit('student_diary_update', diary);
        res.json({ success: true, deleted: true, diary });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message, diary: [] });
    }
}

app.delete('/api/student-diary', deleteStudentDiaryById);
app.delete('/api/student-diary/:id', deleteStudentDiaryById);

function normalizeMessageRole(value) {
    const role = String(value || '').trim().toLowerCase();
    if (role === 'student') return 'Student';
    if (role === 'teacher') return 'Teacher';
    if (role === 'staff') return 'Staff';
    return '';
}

function normalizeMessageScope(value) {
    const scope = String(value || '').trim().toLowerCase();
    return ['all', 'campus', 'class', 'individual'].includes(scope) ? scope : '';
}

function normalizeComparable(value) {
    return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function formatMessageRecord(record) {
    const raw = record && typeof record.toJSON === 'function' ? record.toJSON() : record;
    return {
        ...raw,
        targetRole: normalizeMessageRole(raw?.targetRole),
        targetScope: normalizeMessageScope(raw?.targetScope) || 'all'
    };
}

async function getUserMessageProfile(user = {}) {
    const role = normalizeMessageRole(user.role);
    const id = String(user.id || '').trim();
    if (!role || !id) return { role, id };

    if (role === 'Student') {
        const student = await sequelize.models.Student.findByPk(id);
        return {
            role,
            id,
            username: user.username || student?.username || '',
            fullName: student?.fullName || user.fullName || '',
            campusName: student?.campusName || user.campusName || '',
            classGrade: student?.classGrade || ''
        };
    }

    if (role === 'Teacher') {
        const teacher = await sequelize.models.Teacher.findByPk(id);
        return {
            role,
            id,
            username: user.username || teacher?.username || '',
            fullName: teacher?.fullName || user.fullName || '',
            campusName: teacher?.campusName || user.campusName || ''
        };
    }

    const staff = await sequelize.models.Staff.findByPk(id);
    return {
        role,
        id,
        username: user.username || staff?.username || '',
        fullName: staff?.fullName || user.fullName || '',
        campusName: user.campusName || ''
    };
}

function messageMatchesProfile(message = {}, profile = {}) {
    if (normalizeMessageRole(message.targetRole) !== profile.role) return false;
    const scope = normalizeMessageScope(message.targetScope) || 'all';
    if (scope === 'all') return true;
    if (scope === 'campus') {
        return normalizeComparable(message.campusName) && normalizeComparable(message.campusName) === normalizeComparable(profile.campusName);
    }
    if (scope === 'class') {
        return profile.role === 'Student'
            && normalizeComparable(message.campusName) === normalizeComparable(profile.campusName)
            && normalizeComparable(message.classGrade) === normalizeComparable(profile.classGrade);
    }
    if (scope === 'individual') {
        const target = normalizeComparable(message.recipientId);
        return target && [profile.id, profile.username].map(normalizeComparable).includes(target);
    }
    return false;
}

app.get('/api/messages', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const role = normalizeMessageRole(req.user?.role);
        let records = await sequelize.models.Message.findAll({ order: [['createdAt', 'DESC']] });
        let messages = records.map(formatMessageRecord);

        if (!['Admin', 'Principal'].includes(String(req.user?.role || ''))) {
            const profile = await getUserMessageProfile(req.user);
            messages = messages.filter((message) => messageMatchesProfile(message, profile));
        } else if (req.query.role) {
            const targetRole = normalizeMessageRole(req.query.role);
            messages = targetRole ? messages.filter((message) => message.targetRole === targetRole) : messages;
        }

        res.json({ success: true, role, messages });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/messages', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });
    if (!['Admin', 'Principal'].includes(String(req.user?.role || ''))) {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }

    try {
        const payload = req.body || {};
        const targetRole = normalizeMessageRole(payload.targetRole);
        const targetScope = normalizeMessageScope(payload.targetScope);
        const subject = String(payload.subject || '').trim();
        const body = String(payload.body || '').trim();
        const campusName = String(payload.campusName || '').trim();
        const classGrade = String(payload.classGrade || '').trim();
        const recipientId = String(payload.recipientId || '').trim();

        if (!targetRole || !targetScope || !subject || !body) {
            return res.status(400).json({ success: false, message: 'Role, scope, subject, and message are required.' });
        }
        if (targetScope === 'campus' && !campusName) {
            return res.status(400).json({ success: false, message: 'Select campus for campus message.' });
        }
        if (targetScope === 'class' && (!campusName || !classGrade || targetRole !== 'Student')) {
            return res.status(400).json({ success: false, message: 'Class messages require Student role, campus, and class.' });
        }
        if (targetScope === 'individual' && !recipientId) {
            return res.status(400).json({ success: false, message: 'Select a recipient for individual message.' });
        }

        const message = {
            id: payload.id || `MSG-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            subject,
            body,
            targetRole,
            targetScope,
            campusName: campusName || null,
            classGrade: classGrade || null,
            recipientId: recipientId || null,
            recipientName: String(payload.recipientName || '').trim() || null,
            senderName: req.user.fullName || req.user.username || 'Admin',
            createdAtLabel: new Date().toLocaleString('en-GB')
        };

        await sequelize.models.Message.create(message);
        const records = await sequelize.models.Message.findAll({ order: [['createdAt', 'DESC']] });
        const messages = records.map(formatMessageRecord);
        io.emit('messages_update', messages);
        res.json({ success: true, message: formatMessageRecord(message), messages });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

const SPECIAL_NOTICE_PORTALS = ['student', 'teacher', 'staff'];
const SPECIAL_NOTICE_AUDIENCES = new Set(['portal', 'school', 'class']);

function normalizeNoticeTargets(targetPortals) {
    const allowedTargets = new Set(SPECIAL_NOTICE_PORTALS);
    const targets = Array.isArray(targetPortals) ? targetPortals : [];
    return [...new Set(targets.map((target) => String(target || '').toLowerCase()).filter((target) => allowedTargets.has(target)))];
}

function normalizeNoticeClassGrade(classGrade) {
    return String(classGrade || '').trim();
}

function normalizeNoticeAudienceType(audienceType, targetPortals = [], targetClassGrade = '') {
    const value = String(audienceType || '').trim().toLowerCase();
    if (SPECIAL_NOTICE_AUDIENCES.has(value)) return value;
    if (normalizeNoticeClassGrade(targetClassGrade)) return 'class';
    const targets = normalizeNoticeTargets(targetPortals);
    if (targets.length === SPECIAL_NOTICE_PORTALS.length && SPECIAL_NOTICE_PORTALS.every((target) => targets.includes(target))) {
        return 'school';
    }
    return 'portal';
}

function serializeNoticeTargets(targets) {
    return JSON.stringify(normalizeNoticeTargets(targets));
}

function shouldDeliverSpecialNotice(notice, portal, classGrade = '') {
    const audienceType = normalizeNoticeAudienceType(notice.audienceType, notice.targetPortals, notice.targetClassGrade);
    const normalizedPortal = String(portal || '').toLowerCase();
    if (!normalizedPortal) return true;
    if (audienceType === 'school') {
        return SPECIAL_NOTICE_PORTALS.includes(normalizedPortal);
    }
    if (audienceType === 'class') {
        if (normalizedPortal !== 'student') return false;
        return normalizeNoticeClassGrade(notice.targetClassGrade).toLowerCase() === normalizeNoticeClassGrade(classGrade).toLowerCase();
    }
    return normalizeNoticeTargets(notice.targetPortals).includes(normalizedPortal);
}

function formatSpecialNotice(record) {
    const raw = record && typeof record.toJSON === 'function' ? record.toJSON() : record;
    let targetPortals = [];
    if (Array.isArray(raw.targetPortals)) {
        targetPortals = raw.targetPortals;
    } else {
        try {
            targetPortals = JSON.parse(raw.targetPortals || '[]');
        } catch (error) {
            targetPortals = [];
        }
    }
    const targetClassGrade = normalizeNoticeClassGrade(raw.targetClassGrade || raw.classGrade || '');
    return {
        ...raw,
        audienceType: normalizeNoticeAudienceType(raw.audienceType, targetPortals, targetClassGrade),
        targetPortals: normalizeNoticeTargets(targetPortals),
        targetClassGrade: targetClassGrade || null
    };
}

app.get('/api/special-notices', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const portal = String(req.query.portal || '').toLowerCase();
        const classGrade = String(req.query.classGrade || req.query.class || '').trim();
        const where = portal ? { status: 'executed' } : {};
        const records = await sequelize.models.SpecialNotice.findAll({
            where,
            order: [['updatedAt', 'DESC']]
        });
        const notices = records.map(formatSpecialNotice)
            .filter((notice) => !portal || shouldDeliverSpecialNotice(notice, portal, classGrade));
        res.json({ success: true, notices });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/special-notices', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const payload = req.body || {};
        const title = String(payload.title || '').trim();
        const message = String(payload.message || '').trim();
        const targetPortals = normalizeNoticeTargets(payload.targetPortals);
        const targetClassGrade = normalizeNoticeClassGrade(payload.targetClassGrade || payload.classGrade || '');
        const audienceType = normalizeNoticeAudienceType(payload.audienceType, targetPortals, targetClassGrade);
        const status = payload.status === 'executed' ? 'executed' : 'draft';

        if (!title || !message) {
            return res.status(400).json({ success: false, message: 'Notice title and message are required.' });
        }

        if (audienceType === 'portal' && !targetPortals.length) {
            return res.status(400).json({ success: false, message: 'Select at least one portal before saving this notice.' });
        }

        if (audienceType === 'class' && !targetClassGrade) {
            return res.status(400).json({ success: false, message: 'Select a class before saving this notice.' });
        }

        if (status === 'executed' && audienceType === 'portal' && !targetPortals.length) {
            return res.status(400).json({ success: false, message: 'Select at least one portal before executing.' });
        }

        const id = payload.id || `NOTICE-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const storedTargets = audienceType === 'school'
            ? SPECIAL_NOTICE_PORTALS
            : audienceType === 'class'
                ? ['student']
                : targetPortals;
        const notice = {
            id,
            title,
            message,
            audienceType,
            targetPortals: serializeNoticeTargets(storedTargets),
            targetClassGrade: audienceType === 'class' ? targetClassGrade : null,
            status,
            executedAt: status === 'executed' ? (payload.executedAt || new Date()) : null,
            createdAtLabel: payload.createdAtLabel || new Date().toLocaleString('en-GB')
        };

        await sequelize.models.SpecialNotice.upsert(notice);

        const records = await sequelize.models.SpecialNotice.findAll({
            order: [['updatedAt', 'DESC']]
        });
        const notices = records.map(formatSpecialNotice);
        io.emit('special_notices_update', notices);
        res.json({ success: true, notice: formatSpecialNotice(notice), notices });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.delete('/api/special-notices/:id', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const deletedCount = await sequelize.models.SpecialNotice.destroy({ where: { id: req.params.id } });
        const records = await sequelize.models.SpecialNotice.findAll({
            order: [['updatedAt', 'DESC']]
        });
        const notices = records.map(formatSpecialNotice);
        io.emit('special_notices_update', notices);

        res.json({
            success: true,
            deleted: deletedCount > 0,
            notices
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/reset-data', authenticateToken, async (req, res) => {
    if (req.user.role !== 'Admin') {
        return res.status(403).json({ success: false, message: 'Admin access required.' });
    }

    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const models = sequelize.models;
        const resetOrder = [
            'FeePayment',
            'StudentAttendance',
            'TeacherAttendance',
            'SpecialNotice',
            'Message',
            'ClassFeeHistory',
            'ClassFee',
            'Student',
            'Teacher',
            'Staff',
            'User'
        ];

        for (const modelName of resetOrder) {
            if (models[modelName]) {
                await models[modelName].destroy({ where: {} });
            }
        }

        writePermissions(defaultPermissions);
        activeSessions.clear();

        io.emit('students_update', []);
        io.emit('teachers_update', []);
        io.emit('staff_update', []);
        io.emit('special_notices_update', []);
        io.emit('messages_update', []);

        res.json({ success: true, message: 'System data has been reset.' });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.get('/api/branches', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const branches = await sequelize.models.User.findAll({
            where: { role: 'Branch' },
            attributes: ['id', 'profileId', 'fullName', 'username', 'plainPassword', 'campusName', 'isActive'],
            order: [['campusName', 'ASC']]
        });
        res.json(branches);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/branches', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const User = sequelize.models.User;
        const data = Array.isArray(req.body) ? req.body : [req.body];

        for (const item of data) {
            if (!item.username || !item.campusName) {
                return res.status(400).json({ success: false, message: 'Campus name and username are required.' });
            }

            const branchId = item.profileId || item.id || `branch_${String(item.campusName).toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;
            const existingBranch = item.id ? await User.findByPk(item.id) : await User.findOne({ where: { id: branchId, role: 'Branch' } });
            const rawPassword = item.plainPassword || item.password || existingBranch?.plainPassword || '';

            if (!rawPassword) {
                return res.status(400).json({ success: false, message: 'Password is required.' });
            }

            const passwordHash = item.password
                ? (isPasswordHash(item.password) ? item.password : await bcrypt.hash(item.password, 10))
                : existingBranch?.password;

            await User.upsert({
                id: item.id || branchId,
                profileId: branchId,
                fullName: item.fullName || item.campusName,
                email: normalizeOptionalEmail(item.email),
                username: item.username,
                password: passwordHash,
                plainPassword: rawPassword,
                role: 'Branch',
                campusName: item.campusName,
                isActive: item.isActive !== false
            });
        }

        const branches = await User.findAll({
            where: { role: 'Branch' },
            attributes: ['id', 'profileId', 'fullName', 'username', 'plainPassword', 'campusName', 'isActive'],
            order: [['campusName', 'ASC']]
        });

        res.json({ success: true, branches });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.delete('/api/branches/:id', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const deletedCount = await sequelize.models.User.destroy({
            where: {
                id: req.params.id,
                role: 'Branch'
            }
        });

        if (!deletedCount) {
            return res.status(404).json({ success: false, message: 'Branch not found.' });
        }

        res.json({ success: true, message: 'Branch deleted successfully.' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/student/me', authenticateToken, async (req, res) => {
    if (req.user.role !== 'Student') {
        return res.status(403).json({ success: false, message: 'Student access only.' });
    }

    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const student = await sequelize.models.Student.findByPk(req.user.id, {
            attributes: { exclude: ['password'] }
        });

        if (!student) {
            return res.status(404).json({ success: false, message: 'Student record not found.' });
        }

        return res.json(student);
    } catch (err) {
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/students', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const data = Array.isArray(req.body) ? req.body : [req.body];
        const Student = sequelize.models.Student;
        const User = sequelize.models.User;

        const ids = data.map((item) => String(item?.id || '').trim()).filter(Boolean);
        const existingRows = ids.length
            ? await Student.findAll({ where: { id: ids }, attributes: ['id'] })
            : [];
        const existingIds = new Set(existingRows.map((row) => String(row.id)));

        const needsEdit = data.some((item) => {
            const id = String(item?.id || '').trim();
            return id && existingIds.has(id);
        });
        const needsAdd = data.some((item) => {
            const id = String(item?.id || '').trim();
            return !id || !existingIds.has(id);
        });

        if (needsAdd) {
            const ok = await enforceActionPermission(req, res, 'students', 'add');
            if (!ok) return;
        }
        if (needsEdit) {
            const ok = await enforceActionPermission(req, res, 'students', 'edit');
            if (!ok) return;
        }

        for (const item of data) {
            const normalizedUsername = String(item.username || '').trim();
            const rawPassword = item.plainPassword || item.password || '';
            item.email = normalizeOptionalEmail(item.email);
            item.username = normalizedUsername || null;
            await ensureUniqueStudentIdentity(Student, User, item);
            if (normalizedUsername && item.password && !isPasswordHash(item.password)) {
                item.password = await bcrypt.hash(item.password, 10);
            }
            if (!normalizedUsername) {
                item.password = null;
                item.plainPassword = null;
            } else {
                item.plainPassword = rawPassword || null;
            }

            await Student.upsert(item);
            await upsertAuthUser(User, {
                id: `student_${item.id}`,
                profileId: item.id,
                role: 'Student',
                username: item.username,
                email: normalizeOptionalEmail(item.email),
                password: item.password,
                fullName: item.fullName,
                campusName: item.campusName || null,
                plainPassword: item.plainPassword
            });
        }

        const allStudents = await Student.findAll();
        io.emit('students_update', allStudents);
        res.json({
            success: true,
            savedIds: data.map((item) => String(item.id || '')).filter(Boolean),
            total: allStudents.length
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/students/:id', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const ok = await enforceActionPermission(req, res, 'students', 'delete');
        if (!ok) return;

        const { id } = req.params;
        const Student = sequelize.models.Student;
        const User = sequelize.models.User;

        const deletedCount = await Student.destroy({ where: { id } });
        await User.destroy({
            where: {
                [Op.or]: [
                    { profileId: id, role: 'Student' },
                    { id: `student_${id}` }
                ]
            }
        });

        if (!deletedCount) {
            return res.status(404).json({ success: false, message: 'Student not found.' });
        }

        const allStudents = await Student.findAll();
        io.emit('students_update', allStudents);
        res.json({ success: true, message: 'Student deleted successfully.' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/student-attendance', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const records = await sequelize.models.StudentAttendance.findAll({
            order: [['date', 'ASC']]
        });
        res.json({
            success: true,
            attendance: buildStudentAttendanceStore(records)
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/student-attendance', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const StudentAttendance = sequelize.models.StudentAttendance;
        const payload = Array.isArray(req.body) ? req.body : [req.body];

        for (const item of payload) {
            const studentId = String(item?.studentId || '').trim();
            const date = String(item?.date || '').trim();
            const status = normalizeAttendanceStatus(item?.status);

            if (!studentId || !date) {
                return res.status(400).json({ success: false, message: 'studentId and date are required.' });
            }

            const recordId = `${studentId}_${date}`;

            if (status === 'Not Marked') {
                await StudentAttendance.destroy({ where: { id: recordId } });
                continue;
            }

            await StudentAttendance.upsert({
                id: recordId,
                studentId,
                date,
                status
            });
        }

        const records = await StudentAttendance.findAll({
            order: [['date', 'ASC']]
        });

        res.json({
            success: true,
            attendance: buildStudentAttendanceStore(records)
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


app.get('/api/teacher-attendance', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const records = await sequelize.models.TeacherAttendance.findAll({
            order: [['date', 'ASC']]
        });
        res.json({
            success: true,
            attendance: buildTeacherAttendanceStore(records)
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/teacher-attendance', async (req, res) => {
    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const TeacherAttendance = sequelize.models.TeacherAttendance;
        const payload = Array.isArray(req.body) ? req.body : [req.body];

        for (const item of payload) {
            const teacherId = String(item?.teacherId || '').trim();
            const date = String(item?.date || '').trim();
            const status = normalizeAttendanceStatus(item?.status);

            if (!teacherId || !date) {
                return res.status(400).json({ success: false, message: 'teacherId and date are required.' });
            }

            const recordId = `${teacherId}_${date}`;

            if (status === 'Not Marked') {
                await TeacherAttendance.destroy({ where: { id: recordId } });
                continue;
            }

            await TeacherAttendance.upsert({
                id: recordId,
                teacherId,
                date,
                status
            });
        }

        const records = await TeacherAttendance.findAll({
            order: [['date', 'ASC']]
        });

        res.json({
            success: true,
            attendance: buildTeacherAttendanceStore(records)
        });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});

app.post('/api/fees/challan-token', async (req, res) => {
    try {
        const {
            studentId,
            studentName,
            rollNo,
            classGrade,
            feeMonth,
            feeMonths,
            session,
            amount,
            fullAmount,
            challanNumber
        } = req.body || {};

        if (!studentId || !feeMonth || !challanNumber) {
            return res.status(400).json({ success: false, message: 'Student, fee month, and challan number are required.' });
        }

        const token = jwt.sign({
            studentId,
            studentName: studentName || '',
            rollNo: rollNo || '',
            classGrade: classGrade || '',
            feeMonth,
            feeMonths: Array.isArray(feeMonths) ? feeMonths : [],
            session: session || '',
            amount: Number(amount || 0),
            fullAmount: Number(fullAmount || amount || 0),
            challanNumber
        }, JWT_SECRET, { expiresIn: '120d' });

        const paymentUrl = `${getRequestBaseUrl(req)}/api/fees/pay/${encodeURIComponent(token)}`;
        const qrDataUrl = await QRCode.toDataURL(paymentUrl, {
            errorCorrectionLevel: 'M',
            margin: 1,
            width: 220
        });

        return res.json({
            success: true,
            token,
            paymentUrl,
            qrDataUrl
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
});

app.post('/api/fees/challan-tokens', async (req, res) => {
    try {
        const payload = req.body;
        const items = Array.isArray(payload) ? payload : payload?.items;

        if (!Array.isArray(items) || !items.length) {
            return res.status(400).json({ success: false, message: 'items array is required.' });
        }

        if (items.length > 250) {
            return res.status(400).json({ success: false, message: 'Too many challans requested at once.' });
        }

        const baseUrl = getRequestBaseUrl(req);

        const mapWithConcurrency = async (list, limit, mapper) => {
            const results = new Array(list.length);
            let index = 0;

            const workerCount = Math.min(limit, list.length);
            const workers = Array.from({ length: workerCount }, async () => {
                while (true) {
                    const current = index++;
                    if (current >= list.length) return;
                    results[current] = await mapper(list[current], current);
                }
            });

            await Promise.all(workers);
            return results;
        };

        const tokens = await mapWithConcurrency(items, 6, async (item) => {
            const studentId = String(item?.studentId || '').trim();
            const feeMonth = String(item?.feeMonth || '').trim();
            const challanNumber = String(item?.challanNumber || '').trim();

            if (!studentId || !feeMonth || !challanNumber) {
                const err = new Error('studentId, feeMonth, and challanNumber are required.');
                err.statusCode = 400;
                throw err;
            }

            const token = jwt.sign({
                studentId,
                studentName: item?.studentName || '',
                rollNo: item?.rollNo || '',
                classGrade: item?.classGrade || '',
                feeMonth,
                feeMonths: Array.isArray(item?.feeMonths) ? item.feeMonths : [],
                session: item?.session || '',
                amount: Number(item?.amount || 0),
                fullAmount: Number(item?.fullAmount || item?.amount || 0),
                challanNumber
            }, JWT_SECRET, { expiresIn: '120d' });

            const paymentUrl = `${baseUrl}/api/fees/pay/${encodeURIComponent(token)}`;
            const qrDataUrl = await QRCode.toDataURL(paymentUrl, {
                errorCorrectionLevel: 'M',
                margin: 1,
                width: 220
            });

            return { challanNumber, token, paymentUrl, qrDataUrl };
        });

        return res.json({ success: true, tokens });
    } catch (error) {
        const status = error?.statusCode || 500;
        return res.status(status).json({ success: false, message: error.message || 'Bulk QR code could not be generated.' });
    }
});

const feePaymentWriteLocks = new Map();

async function withFeePaymentWriteLock(studentId, callback) {
    const key = String(studentId || '').trim();
    const previous = feePaymentWriteLocks.get(key) || Promise.resolve();
    let release;
    const current = new Promise((resolve) => { release = resolve; });
    feePaymentWriteLocks.set(key, current);
    await previous;
    try {
        return await callback();
    } finally {
        release();
        if (feePaymentWriteLocks.get(key) === current) feePaymentWriteLocks.delete(key);
    }
}

function getFeePaymentPeriods(monthValues, fallbackMonthLabel, sessionValue, paidAt) {
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const values = Array.isArray(monthValues) && monthValues.length
        ? monthValues.map((value) => String(value || '').trim()).filter(Boolean)
        : String(fallbackMonthLabel || '').split(/[,;|]+/).map((value) => value.trim()).filter(Boolean);
    const fallbackYear = String(fallbackMonthLabel || '').match(/\b((?:19|20)\d{2})\b/);
    const session = String(sessionValue || '').trim();
    const sessionRange = session.match(/\b((?:19|20)\d{2})\s*[-–/]\s*((?:19|20)?\d{2})\b/);
    const startYear = sessionRange ? Number(sessionRange[1]) : Number(session.match(/\b((?:19|20)\d{2})\b/)?.[1] || 0);
    const endYearToken = sessionRange?.[2] || '';
    const endYear = endYearToken
        ? (endYearToken.length === 2 ? Math.floor(startYear / 100) * 100 + Number(endYearToken) : Number(endYearToken))
        : (startYear ? startYear + 1 : 0);
    const paymentDate = paidAt ? new Date(paidAt) : new Date();
    const validPaymentDate = !Number.isNaN(paymentDate.getTime()) ? paymentDate : new Date();
    const periods = new Map();

    values.forEach((label) => {
        const monthMatch = label.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\b/i);
        if (!monthMatch) return;
        const monthIndex = monthNames.findIndex((name) => name.toLowerCase().startsWith(monthMatch[1].slice(0, 3).toLowerCase()));
        if (monthIndex < 0) return;

        const yearMatch = label.match(/\b((?:19|20)\d{2})\b/) || fallbackYear;
        let year = yearMatch ? Number(yearMatch[1]) : 0;
        if (!year) {
            if (startYear) year = monthIndex >= 6 ? startYear : endYear;
            else {
                const dateSessionStart = validPaymentDate.getFullYear() - (validPaymentDate.getMonth() < 6 ? 1 : 0);
                year = monthIndex >= 6 ? dateSessionStart : dateSessionStart + 1;
            }
        }

        const key = `${year}-${String(monthIndex + 1).padStart(2, '0')}`;
        periods.set(key, { key, label: `${monthNames[monthIndex]} ${year}`, monthIndex, year });
    });

    return Array.from(periods.values());
}

async function recordFeePaymentWithMonthlyLimit({ FeePayment, studentId, challanNumber, feeMonth, feeMonths, session, amount, fullAmount, paidAt, buildPayment }) {
    return withFeePaymentWriteLock(studentId, async () => {
        const existingPayment = await FeePayment.findByPk(challanNumber);
        const existingStatus = String(existingPayment?.status || '');
        if (existingPayment && ['Paid', 'Partial'].includes(existingStatus)) {
            if (String(existingPayment.studentId || '') !== String(studentId || '')) {
                const error = new Error('This challan number is already assigned to another student.');
                error.statusCode = 409;
                throw error;
            }
            return { payment: existingPayment.toJSON(), alreadyRecorded: true, remainingDue: 0 };
        }

        const targetPeriods = getFeePaymentPeriods(feeMonths, feeMonth, session, paidAt);
        let remainingDue = Math.max(Number(fullAmount) - Number(amount), 0);
        let paymentStatus = remainingDue > 0 ? 'Partial' : 'Paid';
        if (targetPeriods.length) {
            const monthlyLimit = Number(fullAmount) / targetPeriods.length;
            if (!Number.isFinite(monthlyLimit) || monthlyLimit <= 0) {
                const error = new Error('The monthly fee amount is invalid, so this payment was not recorded.');
                error.statusCode = 400;
                throw error;
            }

            const recordedPayments = await FeePayment.findAll({
                where: {
                    studentId,
                    status: { [Op.in]: ['Paid', 'Partial'] }
                }
            });
            const alreadyPaidByPeriod = new Map();
            recordedPayments.forEach((record) => {
                if (String(record.challanNumber || '') === String(challanNumber || '')) return;
                const recordPeriods = getFeePaymentPeriods([], record.feeMonth, record.session, record.paidAt);
                if (!recordPeriods.length) return;
                const recordAmount = Number(String(record.amount ?? 0).replace(/,/g, ''));
                if (!Number.isFinite(recordAmount) || recordAmount <= 0) return;
                const amountPerPeriod = recordAmount / recordPeriods.length;
                recordPeriods.forEach((period) => {
                    alreadyPaidByPeriod.set(period.key, (alreadyPaidByPeriod.get(period.key) || 0) + amountPerPeriod);
                });
            });

            const paymentAmount = Number(amount);
            const paymentPerPeriod = paymentAmount / targetPeriods.length;
            remainingDue = 0;
            paymentStatus = 'Paid';
            for (const period of targetPeriods) {
                const alreadyPaid = alreadyPaidByPeriod.get(period.key) || 0;
                const proposedTotal = alreadyPaid + paymentPerPeriod;
                if (proposedTotal > monthlyLimit + 0.009) {
                    const remaining = Math.max(monthlyLimit - alreadyPaid, 0);
                    const error = new Error(`${period.label} already has PKR ${alreadyPaid.toLocaleString('en-PK', { maximumFractionDigits: 2 })} paid. Only PKR ${remaining.toLocaleString('en-PK', { maximumFractionDigits: 2 })} remains from the PKR ${monthlyLimit.toLocaleString('en-PK', { maximumFractionDigits: 2 })} monthly fee.`);
                    error.statusCode = 409;
                    throw error;
                }
                remainingDue += Math.max(monthlyLimit - proposedTotal, 0);
                if (proposedTotal + 0.009 < monthlyLimit) paymentStatus = 'Partial';
            }
        }

        const payment = buildPayment(existingPayment, paymentStatus);
        await FeePayment.upsert(payment);
        return { payment, alreadyRecorded: false, remainingDue };
    });
}

app.post('/api/fees/manual-payment', async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const {
            studentId,
            studentName,
            rollNo,
            classGrade,
            feeMonth,
            feeMonths,
            session,
            amount,
            fullAmount,
            paymentDate,
            challanNumber
        } = req.body || {};

        if (!studentId) {
            return res.status(400).json({ success: false, message: 'studentId is required.' });
        }

        const Student = sequelize.models.Student;
        const FeePayment = sequelize.models.FeePayment;
        const FeeDueBalance = sequelize.models.FeeDueBalance;

        const student = await Student.findByPk(studentId);
        if (!student) {
            return res.status(404).json({ success: false, message: 'Student not found.' });
        }

        const paymentAmount = Number(String(amount ?? 0).replace(/,/g, ''));
        if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
            return res.status(400).json({ success: false, message: 'Enter a valid payment amount.' });
        }

        const parsedFullAmount = Number(String(fullAmount ?? amount ?? student.monthlyFee ?? 0).replace(/,/g, ''));
        const safeFullAmount = Number.isFinite(parsedFullAmount) && parsedFullAmount > 0 ? parsedFullAmount : paymentAmount;

        const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        const normalizeMonthList = (value) => Array.isArray(value)
            ? value.map((item) => String(item || '').trim()).filter(Boolean)
            : [];
        const extractMonthList = (value) => {
            const lower = String(value || '').toLowerCase();
            return MONTHS.filter((month) => {
                const full = month.toLowerCase();
                const short = month.slice(0, 3).toLowerCase();
                return lower.includes(full) || lower.includes(short);
            });
        };

        let selectedMonths = normalizeMonthList(feeMonths);
        if (!selectedMonths.length) selectedMonths = extractMonthList(feeMonth);

        const feeMonthRecorded = selectedMonths.length ? selectedMonths.join(', ') : 'Dues';
        const safeChallanNumber = String(challanNumber || '').trim() || `MAN-${Date.now()}`;

        const requestedPaymentDate = String(paymentDate || '').trim();
        const parsedPaymentDate = requestedPaymentDate ? new Date(`${requestedPaymentDate}T12:00:00`) : null;
        const requestedPaidAt = parsedPaymentDate && !Number.isNaN(parsedPaymentDate.getTime()) ? parsedPaymentDate : new Date();
        const { payment: paymentRow, alreadyRecorded } = await recordFeePaymentWithMonthlyLimit({
            FeePayment,
            studentId,
            challanNumber: safeChallanNumber,
            feeMonth: feeMonthRecorded,
            feeMonths: selectedMonths,
            session,
            amount: paymentAmount,
            fullAmount: safeFullAmount,
            paidAt: requestedPaidAt,
            buildPayment: (existingPayment, paymentStatus) => {
                const paidAt = existingPayment?.paidAt || requestedPaidAt;
                return {
                    challanNumber: safeChallanNumber,
                    studentId,
                    studentName: studentName || student.fullName || '',
                    rollNo: rollNo || student.rollNo || '',
                    classGrade: classGrade || student.classGrade || '',
                    session: session || '',
                    feeMonth: feeMonthRecorded,
                    amount: paymentAmount,
                    status: paymentStatus,
                    paidAt,
                    paymentDateLabel: paidAt.toLocaleDateString('en-GB'),
                    paymentSource: 'Manual'
                };
            }
        });
        const paymentDateLabel = paymentRow.paymentDateLabel || new Date(paymentRow.paidAt || requestedPaidAt).toLocaleDateString('en-GB');

        if (!alreadyRecorded && FeeDueBalance) {
            const existingDue = await FeeDueBalance.findByPk(studentId);
            const currentBalance = existingDue ? Number(existingDue.balance || 0) : 0;
            const safeCurrent = Number.isFinite(currentBalance) ? currentBalance : 0;
            const reducedBalance = Math.max(safeCurrent - paymentAmount, 0);

            await FeeDueBalance.upsert({
                studentId,
                balance: reducedBalance,
                updatedAtLabel: new Date().toLocaleString('en-GB')
            });
        }

        const currentMonthName = MONTHS[new Date().getMonth()];
        const currentLower = currentMonthName.toLowerCase();
        const currentShortLower = currentMonthName.slice(0, 3).toLowerCase();
        const currentMonthPaid = selectedMonths.some((month) => {
            const lower = String(month || '').toLowerCase();
            return lower.includes(currentLower) || lower.includes(currentShortLower);
        });

        if (!alreadyRecorded && currentMonthPaid && paymentRow.status === 'Paid') {
            await Student.update({
                feesStatus: 'Paid',
                paymentDate: paymentDateLabel
            }, {
                where: { id: studentId }
            });
        }

        const allStudents = await Student.findAll();
        io.emit('students_update', allStudents);
        io.emit('fee_payment_update', { payment: paymentRow });

        return res.json({ success: true, payment: paymentRow, alreadyRecorded });
    } catch (error) {
        return res.status(error.statusCode || 500).json({ success: false, message: error.message || 'Manual payment failed.' });
    }
});

app.get('/api/fees/payments', async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const FeePayment = sequelize.models.FeePayment;
        const payments = await FeePayment.findAll({
            where: { status: { [Op.in]: ['Paid', 'Partial'] } },
            order: [['paidAt', 'DESC']]
        });

        return res.json({
            success: true,
            payments
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || 'Fee payments could not be loaded.'
        });
    }
});

app.delete('/api/fees/payments/:challanNumber', authenticateToken, async (req, res) => {
    if (String(req.user?.role || '') !== 'Admin') {
        return res.status(403).json({ success: false, message: 'Only an admin can remove a fee payment record.' });
    }
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const { FeePayment, FeeDueBalance, Student } = sequelize.models;
        const challanNumber = String(req.params.challanNumber || '').trim();
        const payment = await FeePayment.findByPk(challanNumber);
        if (!payment || !['Paid', 'Partial'].includes(String(payment.status || ''))) {
            return res.status(404).json({ success: false, message: 'Active payment record was not found.' });
        }

        const amount = Number(payment.amount || 0);
        await payment.update({ status: 'Voided', paymentSource: 'Correction' });

        if (FeeDueBalance && Number.isFinite(amount) && amount > 0) {
            const dueRow = await FeeDueBalance.findByPk(payment.studentId);
            const currentBalance = Number(dueRow?.balance || 0);
            await FeeDueBalance.upsert({
                studentId: payment.studentId,
                balance: (Number.isFinite(currentBalance) ? Math.max(currentBalance, 0) : 0) + amount,
                updatedAtLabel: new Date().toLocaleString('en-GB')
            });
        }

        const now = new Date();
        const pakistanDateParts = new Intl.DateTimeFormat('en-US', {
            timeZone: 'Asia/Karachi',
            year: 'numeric',
            month: '2-digit'
        }).formatToParts(now);
        const currentYear = pakistanDateParts.find((part) => part.type === 'year')?.value || String(now.getFullYear());
        const currentMonth = pakistanDateParts.find((part) => part.type === 'month')?.value || String(now.getMonth() + 1).padStart(2, '0');
        const currentPeriodKey = `${currentYear}-${currentMonth}`;
        const removedPeriods = getFeePaymentPeriods([], payment.feeMonth, payment.session, payment.paidAt);
        if (removedPeriods.some((period) => period.key === currentPeriodKey)) {
            const remainingPayments = await FeePayment.findAll({
                where: {
                    studentId: payment.studentId,
                    status: { [Op.in]: ['Paid', 'Partial'] }
                }
            });
            const anyCurrentMonthPayment = remainingPayments.some((record) =>
                getFeePaymentPeriods([], record.feeMonth, record.session, record.paidAt).some((period) => period.key === currentPeriodKey)
            );
            if (!anyCurrentMonthPayment) {
                await Student.update({ feesStatus: 'Pending', paymentDate: null }, { where: { id: payment.studentId } });
            }
        }

        const students = await Student.findAll();
        io.emit('students_update', students);
        io.emit('fee_payment_update', {
            studentId: payment.studentId,
            challanNumber,
            feeMonth: payment.feeMonth || '',
            status: 'Voided'
        });

        return res.json({ success: true, message: 'Payment was removed and its amount returned to the student due balance.' });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message || 'Payment record could not be removed.' });
    }
});

app.post('/api/fees/mark-unpaid', async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const { studentId, feeMonth, challanNumbers } = req.body || {};
        const sid = String(studentId || '').trim();
        const month = String(feeMonth || '').trim();

        if (!sid || !month) {
            return res.status(400).json({ success: false, message: 'studentId and feeMonth are required.' });
        }

        const Student = sequelize.models.Student;
        const FeePayment = sequelize.models.FeePayment;
        const FeeDueBalance = sequelize.models.FeeDueBalance;
        const student = await Student.findByPk(sid);

        if (!student) {
            return res.status(404).json({ success: false, message: 'Student not found.' });
        }

        const cleanChallans = Array.isArray(challanNumbers)
            ? challanNumbers.map((item) => String(item || '').trim()).filter(Boolean)
            : [];

        const where = {
            studentId: sid,
            status: { [Op.in]: ['Paid', 'Partial'] }
        };

        if (cleanChallans.length) {
            where.challanNumber = { [Op.in]: cleanChallans };
        } else {
            where.feeMonth = { [Op.like]: `%${month}%` };
        }

        const payments = await FeePayment.findAll({ where });
        if (!payments.length) {
            return res.status(404).json({ success: false, message: 'No paid payment record found for this month.' });
        }

        const removedAmount = payments.reduce((sum, payment) => {
            const amount = Number(String(payment.amount ?? 0).replace(/,/g, ''));
            return sum + (Number.isFinite(amount) ? Math.max(amount, 0) : 0);
        }, 0);
        await FeePayment.update({
            status: 'Voided',
            paymentSource: 'Correction'
        }, { where });

        if (FeeDueBalance && removedAmount > 0) {
            const existingDue = await FeeDueBalance.findByPk(sid);
            const currentBalance = existingDue ? Number(existingDue.balance || 0) : 0;
            const safeCurrent = Number.isFinite(currentBalance) ? currentBalance : 0;

            await FeeDueBalance.upsert({
                studentId: sid,
                balance: safeCurrent + removedAmount,
                updatedAtLabel: new Date().toLocaleString('en-GB')
            });
        }

        const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        if (month.toLowerCase() === MONTHS[new Date().getMonth()].toLowerCase()) {
            await Student.update({ feesStatus: 'Pending', paymentDate: null }, { where: { id: sid } });
        }

        const allStudents = await Student.findAll();
        io.emit('students_update', allStudents);
        io.emit('fee_payment_update', { studentId: sid, feeMonth: month, status: 'Voided' });

        return res.json({
            success: true,
            message: 'Fee marked as unpaid.',
            removedCount: payments.length,
            removedAmount
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message || 'Could not mark unpaid.' });
    }
});

app.get('/api/fees/due-balances', async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const FeeDueBalance = sequelize.models.FeeDueBalance;
        if (!FeeDueBalance) {
            return res.json({ success: true, balances: {} });
        }

        const rows = await FeeDueBalance.findAll();
        const balances = rows.reduce((acc, row) => {
            const studentId = String(row.studentId || '').trim();
            if (!studentId) return acc;
            const balance = Number(row.balance || 0);
            acc[studentId] = Number.isFinite(balance) ? balance : 0;
            return acc;
        }, {});

        return res.json({ success: true, balances });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || 'Due balances could not be loaded.'
        });
    }
});

app.post('/api/fees/due-balances', async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const FeeDueBalance = sequelize.models.FeeDueBalance;
        if (!FeeDueBalance) {
            return res.status(503).json({ success: false, message: 'Due balance model is not available.' });
        }

        const studentId = String(req.body?.studentId || req.body?.id || '').trim();
        const rawBalance = String(req.body?.balance ?? req.body?.remainingAmount ?? 0).replace(/,/g, '');
        const parsedBalance = Number(rawBalance);
        const balance = Number.isFinite(parsedBalance) ? Math.max(parsedBalance, 0) : 0;
        if (!studentId) {
            return res.status(400).json({ success: false, message: 'studentId is required.' });
        }

        await FeeDueBalance.upsert({
            studentId,
            balance,
            updatedAtLabel: new Date().toLocaleString('en-GB')
        });

        const rows = await FeeDueBalance.findAll();
        const balances = rows.reduce((acc, row) => {
            const rowStudentId = String(row.studentId || '').trim();
            if (!rowStudentId) return acc;
            const rowBalance = Number(row.balance || 0);
            acc[rowStudentId] = Number.isFinite(rowBalance) ? rowBalance : 0;
            return acc;
        }, {});

        return res.json({
            success: true,
            dueBalance: { studentId, balance },
            balances
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || 'Due balance could not be saved.'
        });
    }
});

app.get('/api/fees/pay/:token', async (req, res) => {
    if (!sequelize) {
        return res.status(503).send(renderFeePaymentPage({
            title: 'Server Offline',
            message: 'The database server is offline, so this fee payment could not be recorded.',
            success: false
        }));
    }

    try {
        const payload = jwt.verify(req.params.token, JWT_SECRET);
        const Student = sequelize.models.Student;
        const FeePayment = sequelize.models.FeePayment;
        const FeeDueBalance = sequelize.models.FeeDueBalance;

        const student = await Student.findByPk(payload.studentId);
        if (!student) {
            return res.status(404).send(renderFeePaymentPage({
                title: 'Student Not Found',
                message: 'This challan is valid, but the linked student record was not found.',
                success: false
            }));
        }

        const paidAt = new Date();

        const paymentAmount = Number(String(payload.amount ?? student.monthlyFee ?? 0).replace(/,/g, ''));
        if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
            return res.status(400).send(renderFeePaymentPage({
                title: 'Invalid Amount',
                message: 'This challan does not contain a valid payable amount.',
                success: false
            }));
        }

        const parsedFullAmount = Number(String(payload.fullAmount ?? payload.amount ?? student.monthlyFee ?? 0).replace(/,/g, ''));
        const fullAmount = Number.isFinite(parsedFullAmount) && parsedFullAmount > 0 ? parsedFullAmount : paymentAmount;

        const normalizeMonthList = (value) => Array.isArray(value)
            ? value.map((item) => String(item || '').trim()).filter(Boolean)
            : [];

        const extractMonthList = (value) => {
            const lower = String(value || '').toLowerCase();
            return MONTHS.filter((month) => {
                const full = month.toLowerCase();
                const short = month.slice(0, 3).toLowerCase();
                return lower.includes(full) || lower.includes(short);
            });
        };

        let selectedMonths = normalizeMonthList(payload.feeMonths);
        if (!selectedMonths.length) selectedMonths = extractMonthList(payload.feeMonth);
        const monthsPaid = selectedMonths;
        const feeMonthRecorded = monthsPaid.length ? monthsPaid.join(', ') : 'Dues';

        const { payment: paymentRow, alreadyRecorded, remainingDue } = await recordFeePaymentWithMonthlyLimit({
            FeePayment,
            studentId: payload.studentId,
            challanNumber: payload.challanNumber,
            feeMonth: feeMonthRecorded,
            feeMonths: monthsPaid,
            session: payload.session,
            amount: paymentAmount,
            fullAmount,
            paidAt,
            buildPayment: (existingPayment, paymentStatus) => {
                const savedAt = existingPayment?.paidAt || paidAt;
                return {
                    challanNumber: payload.challanNumber,
                    studentId: payload.studentId,
                    studentName: payload.studentName || student.fullName || '',
                    rollNo: payload.rollNo || student.rollNo || '',
                    classGrade: payload.classGrade || student.classGrade || '',
                    session: payload.session || '',
                    feeMonth: feeMonthRecorded,
                    amount: paymentAmount,
                    status: paymentStatus,
                    paidAt: savedAt,
                    paymentDateLabel: savedAt.toLocaleDateString('en-GB'),
                    paymentSource: 'QR Scan'
                };
            }
        });
        const paymentDateLabel = paymentRow.paymentDateLabel || new Date(paymentRow.paidAt || paidAt).toLocaleDateString('en-GB');

        if (!alreadyRecorded && FeeDueBalance) {
            const existingDue = await FeeDueBalance.findByPk(payload.studentId);
            const currentBalance = existingDue ? Number(existingDue.balance || 0) : 0;
            const safeCurrent = Number.isFinite(currentBalance) ? currentBalance : 0;
            const reducedBalance = Math.max(safeCurrent - paymentAmount, 0);

            await FeeDueBalance.upsert({
                studentId: payload.studentId,
                balance: reducedBalance,
                updatedAtLabel: new Date().toLocaleString('en-GB')
            });
        }

        const currentMonthName = MONTHS[new Date().getMonth()];
        const feeMonthRaw = String(payload.feeMonth || '');
        const feeMonthLower = feeMonthRaw.toLowerCase();
        const currentLower = currentMonthName.toLowerCase();
        const currentShortLower = currentMonthName.slice(0, 3).toLowerCase();
        const shouldUpdateCurrentMonthStatus = feeMonthLower.includes(currentLower) || feeMonthLower.includes(currentShortLower);

        const currentMonthPaid = monthsPaid.some((month) => {
            const lower = String(month || '').toLowerCase();
            return lower === currentLower || lower === currentShortLower;
        });
        if (!alreadyRecorded && paymentRow.status === 'Paid' && (shouldUpdateCurrentMonthStatus || currentMonthPaid) && monthsPaid.length) {
            await Student.update({
                feesStatus: 'Paid',
                paymentDate: paymentDateLabel
            }, {
                where: { id: payload.studentId }
            });
        }

        const allStudents = await Student.findAll();
        io.emit('students_update', allStudents);
        io.emit('fee_payment_update', { payment: paymentRow });

        return res.send(renderFeePaymentPage({
            title: alreadyRecorded ? 'Already Recorded' : (paymentRow.status === 'Paid' ? 'Fee Marked Paid' : 'Payment Recorded'),
            message: alreadyRecorded
                ? 'This challan was already scanned earlier. The payment remains recorded in the system.'
                : (paymentRow.status === 'Paid'
                    ? 'The fee has been marked as paid successfully in the system.'
                    : 'Payment has been recorded. Remaining amount is still due.'),
            details: [
                { label: 'Student', value: payload.studentName || student.fullName || '-' },
                { label: 'Roll No', value: payload.rollNo || student.rollNo || '-' },
                { label: 'Class', value: payload.classGrade || student.classGrade || '-' },
                { label: 'Fee Month', value: paymentRow.feeMonth || payload.feeMonth || '-' },
                { label: 'Session', value: paymentRow.session || payload.session || '-' },
                { label: 'Amount', value: `PKR ${Number(paymentRow.amount || paymentAmount || 0).toLocaleString('en-PK')}` },
                ...(remainingDue > 0 ? [{ label: 'Remaining Due', value: `PKR ${Number(remainingDue || 0).toLocaleString('en-PK')}` }] : []),
                { label: 'Challan No.', value: payload.challanNumber || '-' },
                { label: 'Paid On', value: paymentDateLabel }
            ],
            success: true
        }));
    } catch (error) {
        return res.status(error.statusCode || 400).send(renderFeePaymentPage({
            title: error.statusCode === 409 ? 'Monthly Fee Limit Reached' : 'Payment Not Recorded',
            message: error.statusCode === 409
                ? error.message
                : 'This QR code is invalid or has expired, so the fee could not be recorded.',
            success: false
        }));
    }
});

app.get('/api/teachers', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const teachers = await sequelize.models.Teacher.findAll({
            attributes: [
                'id', 'employeeCode', 'fullName', 'profileImage', 'fatherName', 'dob', 'cnic', 'phone',
                'email', 'address', 'qualification', 'campusName', 'gender', 'designation', 'subject', 'assignedSections', 'salary',
                'idCardFront', 'idCardBack', 'cvFile', 'bankName', 'bankAccountTitle',
                'bankAccountNumber', 'bankBranch', 'schedule', 'username', 'password', 'plainPassword', 'role', 'groupKey'
            ]
        });
        res.json(teachers);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/teacher/me', authenticateToken, async (req, res) => {
    if (req.user.role !== 'Teacher') {
        return res.status(403).json({ success: false, message: 'Teacher access only.' });
    }

    if (!sequelize) return res.status(503).json({ success: false, message: 'Database offline' });

    try {
        const teacher = await sequelize.models.Teacher.findByPk(req.user.id, {
            attributes: { exclude: ['password'] }
        });

        if (!teacher) {
            return res.status(404).json({ success: false, message: 'Teacher record not found.' });
        }

        return res.json(teacher);
    } catch (err) {
        return res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/staff', async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const staff = await sequelize.models.Staff.findAll();
        res.json(staff);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/teachers', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const data = Array.isArray(req.body) ? req.body : [req.body];
        const Teacher = sequelize.models.Teacher;
        const User = sequelize.models.User;

        const ids = data.map((item) => String(item?.id || '').trim()).filter(Boolean);
        const existingRows = ids.length
            ? await Teacher.findAll({ where: { id: ids }, attributes: ['id'] })
            : [];
        const existingIds = new Set(existingRows.map((row) => String(row.id)));

        const needsEdit = data.some((item) => {
            const id = String(item?.id || '').trim();
            return id && existingIds.has(id);
        });
        const needsAdd = data.some((item) => {
            const id = String(item?.id || '').trim();
            return !id || !existingIds.has(id);
        });

        if (needsAdd) {
            const ok = await enforceActionPermission(req, res, 'teachers', 'add');
            if (!ok) return;
        }
        if (needsEdit) {
            const ok = await enforceActionPermission(req, res, 'teachers', 'edit');
            if (!ok) return;
        }

        for (const item of data) {
            const rawPassword = item.plainPassword || item.password || '';
            item.email = normalizeOptionalEmail(item.email);
            await ensureUniqueTeacherIdentity(Teacher, User, item);
            if (item.password && !isPasswordHash(item.password)) {
                item.password = await bcrypt.hash(item.password, 10);
            }
            item.plainPassword = rawPassword;
            if (Array.isArray(item.schedule)) {
                item.schedule = JSON.stringify(item.schedule);
            }

            await Teacher.upsert(item);
            await upsertAuthUser(User, {
                id: `teacher_${item.id}`,
                profileId: item.id,
                role: 'Teacher',
                username: item.username,
                email: normalizeOptionalEmail(item.email),
                password: item.password,
                fullName: item.fullName,
                campusName: item.campusName,
                plainPassword: item.plainPassword,
                groupKey: item.groupKey || 'teacher'
            });
        }

        const allTeachers = await Teacher.findAll({
            attributes: [
                'id', 'employeeCode', 'fullName', 'profileImage', 'fatherName', 'dob', 'cnic', 'phone',
                'email', 'address', 'qualification', 'campusName', 'gender', 'designation', 'subject', 'assignedSections', 'salary',
                'idCardFront', 'idCardBack', 'cvFile', 'bankName', 'bankAccountTitle',
                'bankAccountNumber', 'bankBranch', 'schedule', 'username', 'password', 'plainPassword', 'role', 'groupKey'
            ]
        });
        io.emit('teachers_update', allTeachers);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/teachers/:id', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const ok = await enforceActionPermission(req, res, 'teachers', 'delete');
        if (!ok) return;

        const { id } = req.params;
        const Teacher = sequelize.models.Teacher;
        const User = sequelize.models.User;

        const deletedCount = await Teacher.destroy({ where: { id } });
        await User.destroy({
            where: {
                [Op.or]: [
                    { profileId: id, role: 'Teacher' },
                    { id: `teacher_${id}` }
                ]
            }
        });

        if (!deletedCount) {
            return res.status(404).json({ success: false, message: 'Teacher not found.' });
        }

        const allTeachers = await Teacher.findAll({
            attributes: [
                'id', 'employeeCode', 'fullName', 'profileImage', 'fatherName', 'dob', 'cnic', 'phone',
                'email', 'address', 'qualification', 'campusName', 'gender', 'designation', 'subject', 'assignedSections', 'salary',
                'idCardFront', 'idCardBack', 'cvFile', 'bankName', 'bankAccountTitle',
                'bankAccountNumber', 'bankBranch', 'schedule', 'username', 'password', 'plainPassword', 'role', 'groupKey'
            ]
        });
        io.emit('teachers_update', allTeachers);
        res.json({ success: true, message: 'Teacher deleted successfully.' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.post('/api/staff', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const data = Array.isArray(req.body) ? req.body : [req.body];
        const Staff = sequelize.models.Staff;
        const User = sequelize.models.User;

        const ids = data.map((item) => String(item?.id || '').trim()).filter(Boolean);
        const existingRows = ids.length
            ? await Staff.findAll({ where: { id: ids }, attributes: ['id'] })
            : [];
        const existingIds = new Set(existingRows.map((row) => String(row.id)));

        const needsEdit = data.some((item) => {
            const id = String(item?.id || '').trim();
            return id && existingIds.has(id);
        });
        const needsAdd = data.some((item) => {
            const id = String(item?.id || '').trim();
            return !id || !existingIds.has(id);
        });

        if (needsAdd) {
            const ok = await enforceActionPermission(req, res, 'staff', 'add');
            if (!ok) return;
        }
        if (needsEdit) {
            const ok = await enforceActionPermission(req, res, 'staff', 'edit');
            if (!ok) return;
        }

        for (const item of data) {
            const rawPassword = item.plainPassword || item.password || '';
            item.email = normalizeOptionalEmail(item.email);

            if (item.password && !isPasswordHash(item.password)) {
                item.password = await bcrypt.hash(item.password, 10);
            }

            item.plainPassword = rawPassword;

            await Staff.upsert(item);
            const staffPermissionGroup = ['accountant', 'office_assistant'].includes(normalizeDesignationKey(item.designation))
                ? normalizeDesignationKey(item.designation)
                : (item.groupKey || 'office_assistant');
            await upsertAuthUser(User, {
                id: `staff_${item.id}`,
                profileId: item.id,
                role: 'Staff',
                username: item.username,
                email: normalizeOptionalEmail(item.email),
                password: item.password,
                fullName: item.fullName,
                plainPassword: item.plainPassword,
                groupKey: staffPermissionGroup
            });
        }

        const allStaff = await Staff.findAll();
        io.emit('staff_update', allStaff);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/staff/:id', authenticateToken, async (req, res) => {
    if (!sequelize) return res.status(503).json({ error: 'Database offline' });

    try {
        const ok = await enforceActionPermission(req, res, 'staff', 'delete');
        if (!ok) return;

        const { id } = req.params;
        const Staff = sequelize.models.Staff;
        const User = sequelize.models.User;

        const deletedCount = await Staff.destroy({ where: { id } });
        await User.destroy({
            where: {
                [Op.or]: [
                    { profileId: id, role: 'Staff' },
                    { id: `staff_${id}` }
                ]
            }
        });

        if (!deletedCount) {
            return res.status(404).json({ success: false, message: 'Staff not found.' });
        }

        const allStaff = await Staff.findAll();
        io.emit('staff_update', allStaff);
        res.json({ success: true, message: 'Staff deleted successfully.' });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

app.get('/api/email/config', authenticateToken, (req, res) => {
    const config = getSmtpConfig();
    res.json({
        success: true,
        configured: Boolean(config.host && config.port && config.user && config.pass && config.fromEmail),
        host: config.host || '',
        port: config.port || 587,
        secure: config.secure,
        user: config.user ? config.user.replace(/^(.{2}).*(@.*)?$/, '$1***$2') : '',
        fromEmail: config.fromEmail || '',
        fromName: config.fromName || ''
    });
});

app.post('/api/email/send', authenticateToken, async (req, res) => {
    try {
        const result = await sendSmtpEmail(req.body || {});
        res.json({
            success: true,
            message: 'Email sent successfully.',
            ...result
        });
    } catch (error) {
        res.status(error.statusCode || 500).json({
            success: false,
            message: error.message || 'Email could not be sent.'
        });
    }
});

app.post('/api/email/execute-all', authenticateToken, async (req, res) => {
    if (!sequelize) {
        return res.status(503).json({ success: false, message: 'Database offline' });
    }

    try {
        const { Student, FeePayment, FeeDueBalance } = sequelize.models;
        const students = await Student.findAll();
        const payments = FeePayment ? await FeePayment.findAll() : [];
        const dueRows = FeeDueBalance ? await FeeDueBalance.findAll() : [];
        const dueMap = new Map(dueRows.map((row) => [String(row.studentId || ''), Number(row.balance || 0) || 0]));
        const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        const currentMonth = months[new Date().getMonth()];
        const currentLower = currentMonth.toLowerCase();
        const currentShort = currentMonth.slice(0, 3).toLowerCase();
        const paidByStudent = new Map();

        payments.forEach((payment) => {
            if (!['paid', 'partial'].includes(String(payment.status || '').toLowerCase())) return;
            if (String(payment.paymentSource || '').toLowerCase().includes('fine')) return;
            const feeMonth = String(payment.feeMonth || '').toLowerCase();
            if (!feeMonth.includes(currentLower) && !feeMonth.includes(currentShort)) return;
            const studentId = String(payment.studentId || '');
            paidByStudent.set(studentId, (paidByStudent.get(studentId) || 0) + (Number(payment.amount || 0) || 0));
        });

        const schoolName = getSmtpConfig().fromName || 'Readers Line Grammer School Jand';
        const result = { pendingFees: { sent: 0, failed: 0, skipped: 0, errors: [] }, birthdays: { sent: 0, failed: 0 }, specialNotices: { sent: 0, failed: 0 } };

        for (const row of students) {
            const student = row.toJSON ? row.toJSON() : row;
            const email = String(student.email || '').trim();
            const status = String(student.enrollmentStatus || student.feesStatus || '').toLowerCase();
            if (!email || status.includes('terminated')) {
                result.pendingFees.skipped += 1;
                continue;
            }

            const monthlyFee = Number(String(student.monthlyFee || student.fee || 0).replace(/,/g, '')) || 0;
            const storedDue = dueMap.has(String(student.id || ''))
                ? dueMap.get(String(student.id || ''))
                : Number(String(student.remainingAmount || 0).replace(/,/g, ''));
            const remainingCharges = Math.max(Number(storedDue || 0), 0);
            const paidAmount = paidByStudent.get(String(student.id || '')) || 0;
            const monthlyPending = Math.max(monthlyFee - paidAmount, 0);
            const totalPending = monthlyPending + remainingCharges;
            if (!(totalPending > 0)) {
                result.pendingFees.skipped += 1;
                continue;
            }

            try {
                const emailBody = buildFeeReminderEmail({
                    schoolName,
                    student,
                    currentMonth,
                    monthlyPending,
                    remainingCharges,
                    totalPending
                });
                await sendSmtpEmail({
                    to: email,
                    subject: `${schoolName} Fee Reminder - ${currentMonth}`,
                    text: emailBody.text,
                    html: emailBody.html
                });
                result.pendingFees.sent += 1;
            } catch (error) {
                result.pendingFees.failed += 1;
                result.pendingFees.errors.push({
                    studentId: student.id || '',
                    email,
                    message: error.message || 'Email failed.'
                });
            }
        }

        return res.json({
            success: true,
            message: result.pendingFees.failed ? 'Some emails failed.' : 'Emails executed successfully.',
            totalSent: result.pendingFees.sent,
            totalFailed: result.pendingFees.failed,
            result
        });
    } catch (error) {
        return res.status(error.statusCode || 500).json({
            success: false,
            message: error.message || 'Emails could not be executed.'
        });
    }
});

registerMobileCollectionRoutes({
    route: 'banners',
    storeName: 'banners',
    recordsKey: 'banners',
    itemKey: 'banner',
    prefix: 'BANNER',
    socketEvent: 'banners_update'
});

registerMobileCollectionRoutes({
    route: 'ads',
    storeName: 'ads',
    recordsKey: 'ads',
    itemKey: 'ad',
    prefix: 'AD',
    socketEvent: 'ads_update'
});

function cleanAdmissionValue(value, maxLength = 500) {
    return String(value ?? '').replace(/[<>]/g, '').trim().slice(0, maxLength);
}

function normalizeAdmissionIdentifier(value) {
    return String(value ?? '').replace(/[^a-z0-9]/gi, '').toUpperCase();
}

app.get('/api/online-admissions', authenticateToken, async (req, res) => {
    if (!(await enforceActionPermission(req, res, 'online_admissions', 'view'))) return;
    return res.json({ success: true, applications: readMobileStore('online_admissions') });
});

app.post('/api/online-admissions', async (req, res) => {
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    if (cleanAdmissionValue(body.website, 200)) return res.status(201).json({ success: true, application: { id: 'received' } });
    const application = {
        id: `ADM-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        studentName: cleanAdmissionValue(body.studentName, 100),
        fatherName: cleanAdmissionValue(body.fatherName, 100),
        dateOfBirth: cleanAdmissionValue(body.dateOfBirth, 20),
        gender: cleanAdmissionValue(body.gender, 20),
        className: cleanAdmissionValue(body.className, 50),
        campus: cleanAdmissionValue(body.campus, 80),
        parentName: cleanAdmissionValue(body.parentName, 100),
        relationship: cleanAdmissionValue(body.relationship, 30),
        phone: cleanAdmissionValue(body.phone, 30),
        alternatePhone: cleanAdmissionValue(body.alternatePhone, 30),
        email: cleanAdmissionValue(body.email, 191).toLowerCase(),
        address: cleanAdmissionValue(body.address, 500),
        previousSchool: cleanAdmissionValue(body.previousSchool, 150),
        previousClass: cleanAdmissionValue(body.previousClass, 60),
        formB: cleanAdmissionValue(body.formB, 50),
        cnic: cleanAdmissionValue(body.cnic, 30),
        message: cleanAdmissionValue(body.message, 1000),
        status: 'New',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    if (!application.studentName || !application.fatherName || !application.dateOfBirth || !application.gender || !application.className || !application.parentName || !application.relationship || !application.phone || !application.address) {
        return res.status(400).json({ success: false, message: 'Please complete all required student, father, parent, contact, class and address fields.' });
    }
    if (application.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(application.email)) {
        return res.status(400).json({ success: false, message: 'Please enter a valid email address.' });
    }
    const formB = normalizeAdmissionIdentifier(application.formB);
    const cnic = normalizeAdmissionIdentifier(application.cnic);
    if (formB || cnic) {
        if (!sequelize) return res.status(503).json({ success: false, message: 'Admissions are temporarily unavailable. Please try again shortly.' });
        const existingApplications = readMobileStore('online_admissions');
        const applicationMatch = existingApplications.some((item) =>
            (formB && normalizeAdmissionIdentifier(item.formB) === formB) ||
            (cnic && normalizeAdmissionIdentifier(item.cnic) === cnic)
        );
        let students;
        try {
            students = await sequelize.models.Student.findAll({ attributes: ['formB', 'cnic'] });
        } catch (error) {
            console.error('Admission duplicate check failed:', error.message);
            return res.status(503).json({ success: false, message: 'Admissions are temporarily unavailable. Please try again shortly.' });
        }
        const studentMatch = students.some((item) =>
            (formB && normalizeAdmissionIdentifier(item.formB) === formB) ||
            (cnic && normalizeAdmissionIdentifier(item.cnic) === cnic)
        );
        if (applicationMatch || studentMatch) {
            return res.status(409).json({
                success: false,
                code: 'ALREADY_APPLIED',
                message: 'An application with this B-Form or CNIC has already been submitted. Please contact the school if you need help.'
            });
        }
    }
    writeMobileStore('online_admissions', [application, ...readMobileStore('online_admissions')]);
    return res.status(201).json({ success: true, application: { id: application.id, status: application.status } });
});

app.post('/api/online-admissions/:id/approve', authenticateToken, async (req, res) => {
    if (!(await enforceActionPermission(req, res, 'online_admissions', 'edit'))) return;
    if (!(await enforceActionPermission(req, res, 'students', 'add'))) return;
    if (!sequelize) return res.status(503).json({ success: false, message: 'Student database is unavailable.' });
    const records = readMobileStore('online_admissions');
    const index = records.findIndex((item) => String(item.id) === String(req.params.id));
    if (index < 0) return res.status(404).json({ success: false, message: 'Application not found.' });
    const application = records[index];
    const Student = sequelize.models.Student;
    let student = application.studentId ? await Student.findByPk(application.studentId) : null;
    let createdNewStudent = false;
    if (!student) {
        const stamp = Date.now().toString(36).toUpperCase();
        const studentId = `STU-ONL-${stamp}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
        const classFees = await sequelize.models.ClassFee.findAll();
        const classFee = classFees.find((item) => String(item.className || '').trim().toLowerCase() === String(application.className || '').trim().toLowerCase());
        const emailAlreadyUsed = application.email ? await Student.findOne({ where: { email: application.email } }) : null;
        const today = new Date().toISOString().slice(0, 10);
        try {
            student = await Student.create({
                id: studentId,
                studentCode: `ONL-${stamp}`,
                fullName: application.studentName,
                fatherName: application.fatherName,
                dob: application.dateOfBirth,
                admissionDate: today,
                classGrade: application.className,
                section: 'General',
                campusName: application.campus || req.user.campusName || 'Main Campus',
                gender: application.gender,
                parentPhone: application.phone,
                guardianName: application.parentName,
                guardianContact: application.phone,
                email: emailAlreadyUsed ? null : (application.email || null),
                address: application.address,
                formB: application.formB || '',
                cnic: application.cnic || '',
                monthlyFee: classFee?.monthlyFee ? String(classFee.monthlyFee) : '',
                monthlyFeeCustom: false,
                freeStudy: false,
                remainingAmount: '0',
                feeFrequency: classFee?.feeFrequency || 'Monthly',
                feesStatus: 'Pending',
                enrollmentStatus: 'Active',
                role: 'Student'
            });
            createdNewStudent = true;
        } catch (error) {
            return res.status(409).json({ success: false, message: error.message || 'Student record could not be created.' });
        }
        application.studentId = student.id;
        application.studentCode = student.studentCode;
    }
    application.status = 'Approved';
    application.updatedAt = new Date().toISOString();
    records[index] = application;
    let applications;
    try {
        applications = writeMobileStore('online_admissions', records);
    } catch (error) {
        if (createdNewStudent && student) await Student.destroy({ where: { id: student.id } }).catch(() => {});
        return res.status(500).json({ success: false, message: 'Student was created but the application could not be updated. Contact the administrator.' });
    }
    const students = await Student.findAll();
    io.emit('students_update', students);
    return res.json({ success: true, application, student: { id: student.id, studentCode: student.studentCode }, applications });
});

app.post('/api/online-admissions/:id', authenticateToken, async (req, res) => {
    if (!(await enforceActionPermission(req, res, 'online_admissions', 'edit'))) return;
    const records = readMobileStore('online_admissions');
    const index = records.findIndex((item) => String(item.id) === String(req.params.id));
    if (index < 0) return res.status(404).json({ success: false, message: 'Application not found.' });
    const status = String(req.body?.status || '').trim();
    if (!['New', 'Contacted', 'Closed', 'Rejected', 'Approved'].includes(status)) return res.status(400).json({ success: false, message: 'Invalid application status.' });
    records[index] = { ...records[index], status, updatedAt: new Date().toISOString() };
    const applications = writeMobileStore('online_admissions', records);
    return res.json({ success: true, application: records[index], applications });
});

app.delete('/api/online-admissions/:id', authenticateToken, async (req, res) => {
    if (!(await enforceActionPermission(req, res, 'online_admissions', 'delete'))) return;
    const applications = deleteMobileRecord('online_admissions', req.params.id);
    return res.json({ success: true, deleted: true, applications });
});

registerMobileCollectionRoutes({ route: 'library/issues', storeName: 'library_issues', recordsKey: 'issues', itemKey: 'issue', prefix: 'LIB' });
app.post('/api/library/issues/:id/return', (req, res) => {
    const records = readMobileStore('library_issues');
    const index = records.findIndex((item) => String(item.id) === String(req.params.id));
    if (index < 0) return res.status(404).json({ success: false, message: 'Library issue not found.' });
    records[index] = {
        ...records[index],
        status: 'Returned',
        returnDate: req.body?.returnDate || new Date().toISOString().slice(0, 10),
        updatedAt: new Date().toISOString()
    };
    res.json({ success: true, issue: records[index], issues: writeMobileStore('library_issues', records) });
});

registerMobileCollectionRoutes({ route: 'cafe/contracts', storeName: 'cafe_contracts', recordsKey: 'contracts', itemKey: 'contract', prefix: 'CAFE' });
registerMobileCollectionRoutes({ route: 'transport/assignments', storeName: 'transport_assignments', recordsKey: 'assignments', itemKey: 'assignment', prefix: 'TRN' });
registerMobileCollectionRoutes({ route: 'student-assignments', storeName: 'student_assignments', recordsKey: 'assignments', itemKey: 'assignment', prefix: 'ASG' });
registerMobileCollectionRoutes({ route: 'teacher-salaries', storeName: 'teacher_salaries', recordsKey: 'salaries', itemKey: 'salary', prefix: 'SAL' });
registerMobileCollectionRoutes({ route: 'student-courses', storeName: 'student_courses', recordsKey: 'courses', itemKey: 'course', prefix: 'COURSE' });
registerMobileCollectionRoutes({ route: 'uploaded-assignments', storeName: 'uploaded_assignments', recordsKey: 'assignments', itemKey: 'assignment', prefix: 'UPLOAD-ASG' });
registerMobileCollectionRoutes({ route: 'uploaded-lectures', storeName: 'uploaded_lectures', recordsKey: 'lectures', itemKey: 'lecture', prefix: 'LECTURE' });
registerMobileCollectionRoutes({ route: 'student-quizzes', storeName: 'student_quizzes', recordsKey: 'quizzes', itemKey: 'quiz', prefix: 'QUIZ' });
registerMobileCollectionRoutes({ route: 'student-quiz-submissions', storeName: 'student_quiz_submissions', recordsKey: 'submissions', itemKey: 'submission', prefix: 'QUIZ-SUB' });
registerMobileCollectionRoutes({ route: 'student-results', storeName: 'student_results', recordsKey: 'results', itemKey: 'result', prefix: 'RESULT' });
registerMobileCollectionRoutes({ route: 'result-publish-schedules', storeName: 'result_publish_schedules', recordsKey: 'schedules', itemKey: 'schedule', prefix: 'RESULT-SCHEDULE' });
registerMobileCollectionRoutes({ route: 'student-syllabus', storeName: 'student_syllabus', recordsKey: 'syllabus', itemKey: 'syllabusItem', prefix: 'SYL' });
registerMobileCollectionRoutes({ route: 'teacher-assigned-classes', storeName: 'teacher_assigned_classes', recordsKey: 'assignedClasses', itemKey: 'assignedClass', prefix: 'TCLASS' });

app.get('/api/student-performance', authenticateToken, async (req, res) => {
    try {
        await sequelize.models.StudentPerformance.sync();
        const studentId = String(req.query.studentId || '').trim();
        const subject = String(req.query.subject || '').trim();
        const where = {
            ...(studentId ? { studentId } : {}),
            ...(subject ? { subject } : {})
        };
        const performances = await sequelize.models.StudentPerformance.findAll({
            where,
            order: [['performanceDate', 'DESC'], ['subject', 'ASC'], ['skill', 'ASC']]
        });
        return res.json({ success: true, performances });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
});

app.post('/api/student-performance', authenticateToken, async (req, res) => {
    try {
        await sequelize.models.StudentPerformance.sync();
        const items = Array.isArray(req.body) ? req.body : [req.body];
        if (!items.length) return res.status(400).json({ success: false, message: 'Performance records are required.' });

        for (const item of items) {
            const studentId = String(item.studentId || '').trim();
            const subject = String(item.subject || '').trim();
            const skill = String(item.skill || '').trim();
            const learningOutcome = String(item.learningOutcome || '').trim();
            const excellentDescription = String(item.excellentDescription || '').trim();
            const satisfactoryDescription = String(item.satisfactoryDescription || '').trim();
            const needsPracticeDescription = String(item.needsPracticeDescription || '').trim();
            const rating = String(item.rating || '').trim();
            const performanceDate = String(item.performanceDate || item.date || new Date().toISOString().slice(0, 10)).trim();
            const performanceMonth = String(item.performanceMonth || performanceDate.slice(0, 7)).trim();
            const percentage = Number(item.percentage ?? 0);
            if (!studentId || !subject) {
                return res.status(400).json({ success: false, message: 'Student and subject are required.' });
            }
            if (req.user?.role === 'Teacher') {
                const teacher = await sequelize.models.Teacher.findByPk(req.user.id, { attributes: ['subject'] });
                const assignedSubjects = String(teacher?.subject || '').split(/[,|]/).map(value => value.trim().toLowerCase()).filter(Boolean);
                const specialTeacherReports = ['co-curriculum', 'participation'];
                if (!assignedSubjects.includes(subject.toLowerCase()) && !specialTeacherReports.includes(subject.toLowerCase())) {
                    return res.status(403).json({ success: false, message: 'You can only add performance for your assigned subject.' });
                }
            }
            if (skill && skill !== '__subject_marks__' && (!learningOutcome || !['Excellent', 'Satisfactory', 'Needs Practice'].includes(rating))) {
                return res.status(400).json({ success: false, message: 'Skill, learning outcome, and rating are required.' });
            }
            if (skill && skill !== '__subject_marks__' && ((excellentDescription && satisfactoryDescription) || (!excellentDescription && !satisfactoryDescription && !needsPracticeDescription))) {
                return res.status(400).json({ success: false, message: 'Enter Excellent, or enter Satisfactory and/or Needs Practice.' });
            }
            if (!Number.isFinite(percentage) || percentage < 0 || percentage > 100) {
                return res.status(400).json({ success: false, message: 'Percentage must be from 0 to 100.' });
            }
            const id = String(item.id || `PERF-${studentId}-${subject}-${performanceDate}-${skill || 'summary'}`).replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 255);
            const grade = percentage >= 90 ? 'A+' : percentage >= 80 ? 'A' : percentage >= 70 ? 'B' : percentage >= 60 ? 'C' : percentage >= 50 ? 'D' : 'F';
            await sequelize.models.StudentPerformance.upsert({
                id,
                studentId,
                studentName: String(item.studentName || '').trim(),
                classGrade: String(item.classGrade || '').trim(),
                section: String(item.section || item.classSection || 'General').trim() || 'General',
                subject,
                examType: String(item.examType || '').trim() || null,
                examYear: String(item.examYear || '').trim() || null,
                obtainedMarks: item.obtainedMarks == null || item.obtainedMarks === '' ? null : Number(item.obtainedMarks),
                totalMarks: item.totalMarks == null || item.totalMarks === '' ? null : Number(item.totalMarks),
                percentage,
                grade,
                skill,
                learningOutcome,
                rating,
                excellentDescription,
                satisfactoryDescription,
                needsPracticeDescription,
                performanceDate,
                performanceMonth,
                remarks: String(item.remarks || '').trim(),
                updatedAtLabel: new Date().toISOString()
            });
        }

        const studentId = String(items[0]?.studentId || '').trim();
        const performances = await sequelize.models.StudentPerformance.findAll({
            where: studentId ? { studentId } : {},
            order: [['performanceDate', 'DESC'], ['subject', 'ASC'], ['skill', 'ASC']]
        });
        io.emit('student_performance_update', { studentId, performances });
        return res.json({ success: true, performances });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
});

app.delete('/api/student-performance', authenticateToken, async (req, res) => {
    try {
        const recordId = String(req.query.recordId || '').trim();
        if (!recordId) return res.status(400).json({ success: false, message: 'Performance record id is required.' });
        await sequelize.models.StudentPerformance.destroy({ where: { id: recordId } });
        return res.json({ success: true, message: 'Performance record deleted.' });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
});

app.delete('/api/student-performance/:studentId', authenticateToken, async (req, res) => {
    try {
        const studentId = String(req.params.studentId || '').trim();
        await sequelize.models.StudentPerformance.destroy({ where: { studentId } });
        return res.json({ success: true, message: 'Student performance records deleted.' });
    } catch (error) {
        return res.status(500).json({ success: false, message: error.message });
    }
});

app.get('/api/about-software', (_req, res) => {
    const records = readMobileStore('about_software');
    res.json({
        success: true,
        aboutSoftware: records[0] || {
            id: 'ABOUT-SOFTWARE',
            appName: 'Readers Line Grammer School Jand',
            schoolName: 'Readers Line Grammer School Jand',
            website: process.env.SCHOOL_WEBSITE || '',
            supportEmail: process.env.SMTP_FROM_EMAIL || '',
            supportPhone: '+92 300 5203469',
            schoolAddress: 'Haji Bazar Chowk, Tehsil Road Jand.',
            principalName: 'Malik M. Tahir Suleman',
            description: 'Student and teacher portal APIs for Readers Line Grammer School Jand.',
            version: '1.0.0'
        }
    });
});

app.post('/api/about-software', (req, res) => {
    const { record } = upsertMobileRecord('about_software', {
        id: req.body?.id || 'ABOUT-SOFTWARE',
        ...(req.body || {})
    }, 'ABOUT');
    res.json({ success: true, aboutSoftware: record });
});

app.get('/api/leave-requests', (req, res) => {
    let leaveRequests = readMobileStore('leave_requests');
    const role = String(req.query.role || '').trim().toLowerCase();
    if (role) {
        leaveRequests = leaveRequests.filter((item) => String(item.applicantRole || item.role || '').trim().toLowerCase() === role);
    }
    res.json({ success: true, leaveRequests });
});

app.post('/api/leave-requests', (req, res) => {
    const role = req.user?.role || req.body?.applicantRole || req.body?.role || 'Student';
    const applicantId = req.user?.id || req.body?.applicantId || req.body?.studentId || req.body?.teacherId || '';
    const applicantName = req.user?.fullName || req.body?.applicantName || req.body?.studentName || req.body?.teacherName || '';
    const { record, records } = upsertMobileRecord('leave_requests', {
        status: 'Pending',
        ...req.body,
        applicantRole: role,
        applicantId,
        applicantName
    }, 'LEAVE');
    res.json({ success: true, leaveRequest: record, leaveRequests: records });
});

app.post('/api/leave-requests/:id', (req, res) => {
    const records = readMobileStore('leave_requests');
    const index = records.findIndex((item) => String(item.id) === String(req.params.id));
    if (index < 0) return res.status(404).json({ success: false, message: 'Leave request not found.' });
    records[index] = {
        ...records[index],
        ...req.body,
        status: req.body?.status || records[index].status || 'Pending',
        reviewedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    res.json({ success: true, leaveRequest: records[index], leaveRequests: writeMobileStore('leave_requests', records) });
});

app.delete('/api/leave-requests/:id', (req, res) => {
    const leaveRequests = deleteMobileRecord('leave_requests', req.params.id);
    res.json({ success: true, deleted: true, leaveRequests });
});

app.get('/api/complaints', (req, res) => {
    let complaints = readMobileStore('complaints');
    const role = String(req.query.role || req.query.senderRole || '').trim().toLowerCase();
    const senderId = String(req.query.senderId || req.query.studentId || req.query.teacherId || '').trim();
    const status = String(req.query.status || '').trim().toLowerCase();
    if (role) {
        complaints = complaints.filter((item) => String(item.senderRole || '').trim().toLowerCase() === role);
    }
    if (senderId) {
        complaints = complaints.filter((item) => String(item.senderId || item.studentId || item.teacherId || '') === senderId);
    }
    if (status) {
        complaints = complaints.filter((item) => String(item.status || '').trim().toLowerCase() === status);
    }
    res.json({ success: true, complaints });
});

app.post('/api/complaints', (req, res) => {
    const role = req.user?.role || req.body?.senderRole || req.body?.role || req.body?.complainantRole || 'Student';
    const senderRole = /^teacher$/i.test(role) ? 'Teacher' : (/^(family|parent|parents)$/i.test(role) ? 'Family' : 'Student');
    const { record, records } = upsertMobileRecord('complaints', {
        status: 'Pending',
        ...req.body,
        senderRole,
        senderId: req.user?.id || req.body?.senderId || req.body?.studentId || req.body?.teacherId || '',
        senderName: req.user?.fullName || req.body?.senderName || req.body?.studentName || req.body?.teacherName || req.body?.parentName || req.body?.familyName || '',
        senderClass: req.body?.senderClass || req.body?.className || req.body?.class || '',
        subject: req.body?.subject || 'Complaint',
        message: req.body?.message || req.body?.complaint || req.body?.details || '',
        status: req.body?.status || 'Pending'
    }, 'CMP');
    io.emit('complaints_update', records);
    res.json({ success: true, complaint: record, complaints: records });
});

app.post('/api/complaints/:id', (req, res) => {
    const records = readMobileStore('complaints');
    const index = records.findIndex((item) => String(item.id) === String(req.params.id));
    if (index < 0) return res.status(404).json({ success: false, message: 'Complaint not found.' });
    records[index] = {
        ...records[index],
        ...req.body,
        status: req.body?.status || records[index].status || 'Pending',
        updatedAt: new Date().toISOString()
    };
    const complaints = writeMobileStore('complaints', records);
    io.emit('complaints_update', complaints);
    res.json({ success: true, complaint: records[index], complaints });
});

app.delete('/api/complaints/:id', (req, res) => {
    const complaints = deleteMobileRecord('complaints', req.params.id);
    io.emit('complaints_update', complaints);
    res.json({ success: true, deleted: true, complaints });
});

app.get('/api/fees/fine-charge', (_req, res) => {
    res.json(getMobileRecordsPayload('fineCharges', 'fee_fine_charges'));
});

app.post('/api/fees/fine-charge', (req, res) => {
    const { record, records } = upsertMobileRecord('fee_fine_charges', req.body || {}, 'FINE');
    res.json({ success: true, fineCharge: record, fineCharges: records });
});

function trimAiText(value = '', maxLength = 180) {
    const text = String(value || '').replace(/\s+/g, ' ').trim();
    return text.length > maxLength ? `${text.slice(0, maxLength - 3)}...` : text;
}

function pickSafePersonFields(item = {}, type = 'student') {
    if (type === 'student') {
        return {
            id: item.studentCode || item.id || '',
            name: item.fullName || '',
            class: item.classGrade || '',
            campus: item.campusName || '',
            rollNo: item.rollNo || '',
            feeStatus: item.feesStatus || '',
            monthlyFee: item.monthlyFee || ''
        };
    }
    if (type === 'teacher') {
        return {
            id: item.employeeCode || item.id || '',
            name: item.fullName || '',
            campus: item.campusName || '',
            subject: item.subject || '',
            designation: item.designation || '',
            salary: item.salary || ''
        };
    }
    return {
        id: item.employeeCode || item.id || '',
        name: item.fullName || '',
        campus: item.campusName || '',
        designation: item.designation || '',
        salary: item.salary || ''
    };
}

async function buildAiSchoolContext(user = {}) {
    if (!sequelize || !isInitialized) {
        return {
            online: false,
            message: 'Database is offline. Only general portal guidance is available.'
        };
    }

    const { Student, Teacher, Staff, ClassFee, FeePayment, FeeDueBalance } = sequelize.models;
    const campusFilter = String(user?.campusName || '').trim();
    const role = String(user?.role || '').trim();
    const whereCampus = campusFilter && !['Admin', 'Principal'].includes(role) ? { campusName: campusFilter } : {};

    const [students, teachers, staff, classFees, payments, dueBalances] = await Promise.all([
        Student ? Student.findAll({ where: whereCampus, order: [['fullName', 'ASC']], limit: 80 }) : [],
        Teacher ? Teacher.findAll({ where: whereCampus, order: [['fullName', 'ASC']], limit: 80 }) : [],
        Staff ? Staff.findAll({ where: whereCampus, order: [['fullName', 'ASC']], limit: 80 }) : [],
        ClassFee ? ClassFee.findAll({ order: [['className', 'ASC']] }) : [],
        FeePayment ? FeePayment.findAll({ order: [['paidAt', 'DESC']], limit: 20 }) : [],
        FeeDueBalance ? FeeDueBalance.findAll({ limit: 80 }) : []
    ]);

    const safeStudents = students.map((item) => pickSafePersonFields(item.get ? item.get({ plain: true }) : item, 'student'));
    const safeTeachers = teachers.map((item) => pickSafePersonFields(item.get ? item.get({ plain: true }) : item, 'teacher'));
    const safeStaff = staff.map((item) => pickSafePersonFields(item.get ? item.get({ plain: true }) : item, 'staff'));
    const campusNames = Array.from(new Set([
        ...safeStudents.map((item) => item.campus),
        ...safeTeachers.map((item) => item.campus),
        ...safeStaff.map((item) => item.campus)
    ].filter(Boolean)));
    const classNames = Array.from(new Set(safeStudents.map((item) => item.class).filter(Boolean)));

    return {
        online: true,
        user: {
            role,
            id: user?.id || '',
            campusName: campusFilter || 'All campuses'
        },
        summary: {
            students: safeStudents.length,
            teachers: safeTeachers.length,
            staff: safeStaff.length,
            campuses: campusNames,
            classes: classNames
        },
        students: safeStudents.slice(0, 50),
        teachers: safeTeachers.slice(0, 50),
        staff: safeStaff.slice(0, 50),
        classFees: classFees.map((item) => {
            const row = item.get ? item.get({ plain: true }) : item;
            return { className: row.className || '', monthlyFee: row.monthlyFee || 0 };
        }).slice(0, 40),
        recentPayments: payments.map((item) => {
            const row = item.get ? item.get({ plain: true }) : item;
            return {
                studentName: row.studentName || '',
                rollNo: row.rollNo || '',
                classGrade: row.classGrade || '',
                campusName: row.campusName || '',
                feeMonth: row.feeMonth || '',
                amount: row.amount || 0,
                status: row.status || '',
                paidAt: row.paidAt || ''
            };
        }),
        dueBalances: dueBalances.map((item) => {
            const row = item.get ? item.get({ plain: true }) : item;
            return {
                studentId: row.studentId || '',
                studentName: row.studentName || '',
                rollNo: row.rollNo || '',
                pendingBalance: row.pendingBalance || 0
            };
        }).slice(0, 50)
    };
}

function buildLocalAiAnswer(question = '', context = {}) {
    const q = String(question || '').toLowerCase();
    const summary = context.summary || {};
    if (!context.online) return context.message || 'Database offline hai, is waqt detailed school data available nahi.';
    if (q.includes('student')) {
        return `System me ${summary.students || 0} students hain. Classes: ${(summary.classes || []).join(', ') || '-'}. Campus: ${(summary.campuses || []).join(', ') || '-'}.`;
    }
    if (q.includes('teacher')) {
        return `System me ${summary.teachers || 0} teachers hain. Teacher list ke liye Teachers module open karein.`;
    }
    if (q.includes('staff')) {
        return `System me ${summary.staff || 0} staff members hain. Staff details Staff module me available hain.`;
    }
    if (q.includes('fee') || q.includes('fees') || q.includes('revenue')) {
        const totalRecent = (context.recentPayments || []).reduce((sum, item) => sum + Number(item.amount || 0), 0);
        return `Recent saved payments total PKR ${totalRecent.toLocaleString()} hai. Detailed branch/class revenue ke liye Finance/Revenue page use karein.`;
    }
    return `Main school system context ke hisab se help kar sakta hun. Current snapshot: ${summary.students || 0} students, ${summary.teachers || 0} teachers, ${summary.staff || 0} staff, campuses: ${(summary.campuses || []).join(', ') || '-'}.`;
}

async function callOpenAiForSchoolAnswer(message, context) {
    const prompt = [
        'You are Readers Line Grammer School Jand portal assistant.',
        'Answer in the same language style as the user. Most users write Roman Urdu.',
        'Use only the provided school system context. If exact data is not present, say that it is not available in the current system snapshot.',
        'Do not expose passwords, secrets, API keys, or hidden implementation details.',
        'Keep answers concise and practical.',
        '',
        `School context JSON:\n${JSON.stringify(context).slice(0, 18000)}`,
        '',
        `User question: ${trimAiText(message, 1000)}`
    ].join('\n');

    const response = await axios.post('https://api.openai.com/v1/responses', {
        model: OPENAI_MODEL,
        input: prompt,
        max_output_tokens: 450
    }, {
        headers: {
            Authorization: `Bearer ${OPENAI_API_KEY}`,
            'Content-Type': 'application/json'
        },
        timeout: 20000
    });

    const data = response.data || {};
    if (typeof data.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
    const outputText = (data.output || [])
        .flatMap((item) => item.content || [])
        .map((part) => part.text || '')
        .join('')
        .trim();
    return outputText || '';
}

app.post('/api/ai-chat', authenticateToken, async (req, res) => {
    try {
        const message = trimAiText(req.body?.message || '', 1200);
        if (!message) {
            return res.status(400).json({ success: false, message: 'Message is required.' });
        }

        const context = await buildAiSchoolContext(req.user || {});
        let answer = '';
        let provider = 'local';

        if (OPENAI_API_KEY) {
            try {
                answer = await callOpenAiForSchoolAnswer(message, context);
                provider = 'openai';
            } catch (error) {
                console.warn('AI provider failed:', error?.response?.data || error.message);
            }
        }

        if (!answer) answer = buildLocalAiAnswer(message, context);

        res.json({
            success: true,
            provider,
            answer
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: error.message || 'AI chat could not respond.'
        });
    }
});

app.all('/api', (req, res) => {
    res.status(404).json({
        success: false,
        message: `API route not found: ${req.method} ${req.originalUrl}`
    });
});

app.all('/api/*', (req, res) => {
    res.status(404).json({
        success: false,
        message: `API route not found: ${req.method} ${req.originalUrl}`
    });
});

app.use((err, req, res, next) => {
    if (res.headersSent) {
        return next(err);
    }

    if (req.originalUrl && req.originalUrl.startsWith('/api')) {
        return res.status(err.status || 500).json({
            success: false,
            message: err.message || 'Internal server error.'
        });
    }

    return next(err);
});

function defineStudentModel(db) {
    return db.define('Student', {
        id: { type: DataTypes.STRING(100), primaryKey: true },
        studentCode: DataTypes.STRING(50),
        fullName: DataTypes.STRING(100),
        profileImage: DataTypes.TEXT('long'),
        fatherName: DataTypes.STRING(100),
        dob: DataTypes.STRING(20),
        admissionDate: DataTypes.STRING(20),
        classGrade: DataTypes.STRING(50),
        section: DataTypes.STRING(30),
        subjects: DataTypes.TEXT,
        campusName: DataTypes.STRING(80),
        gender: DataTypes.STRING(20),
        parentPhone: DataTypes.STRING(30),
        email: { type: DataTypes.STRING(191), unique: true, allowNull: true },
        rollNo: DataTypes.STRING(30),
        formB: DataTypes.STRING(50),
        cnic: DataTypes.STRING(30),
        monthlyFee: DataTypes.STRING(20),
        monthlyFeeCustom: DataTypes.BOOLEAN,
        freeStudy: DataTypes.BOOLEAN,
        zeroFeeReason: DataTypes.TEXT,
        remainingAmount: DataTypes.STRING(20),
        dueBalance: DataTypes.STRING(20),
        balance: DataTypes.STRING(20),
        feeFrequency: DataTypes.STRING(30),
        feesStatus: { type: DataTypes.STRING(30), defaultValue: 'Pending' },
        enrollmentStatus: DataTypes.STRING(30),
        paymentDate: DataTypes.STRING(30),
        address: DataTypes.TEXT,
        guardianName: DataTypes.STRING(100),
        guardianContact: DataTypes.STRING(30),
        fingerprintData: DataTypes.TEXT('long'),
        familyId: DataTypes.STRING(60),
        familyName: DataTypes.STRING(100),
        familyNo: DataTypes.STRING(50),
        familyContact: DataTypes.STRING(30),
        familyAddedAt: DataTypes.STRING(30),
        username: { type: DataTypes.STRING(100), unique: true },
        password: DataTypes.STRING(255),
        plainPassword: DataTypes.TEXT,
        role: { type: DataTypes.STRING(30), defaultValue: 'Student' }
    }, { engine: 'InnoDB', rowFormat: 'DYNAMIC' });
}

function defineTeacherModel(db) {
    return db.define('Teacher', {
        id: { type: DataTypes.STRING, primaryKey: true },
        employeeCode: DataTypes.STRING,
        fullName: DataTypes.STRING,
        profileImage: DataTypes.TEXT('long'),
        fatherName: DataTypes.STRING,
        dob: DataTypes.STRING,
        cnic: DataTypes.STRING,
        phone: DataTypes.STRING,
        email: { type: DataTypes.STRING, unique: true, allowNull: true },
        address: DataTypes.TEXT,
        qualification: DataTypes.STRING,
        campusName: DataTypes.STRING,
        gender: DataTypes.STRING,
        designation: DataTypes.STRING,
        subject: DataTypes.STRING,
        assignedSections: DataTypes.TEXT,
        salary: DataTypes.STRING,
        idCardFront: DataTypes.TEXT('long'),
        idCardBack: DataTypes.TEXT('long'),
        cvFile: DataTypes.TEXT('long'),
        bankName: DataTypes.STRING,
        bankAccountTitle: DataTypes.STRING,
        bankAccountNumber: DataTypes.STRING,
        bankBranch: DataTypes.STRING,
        schedule: DataTypes.TEXT('long'),
        username: { type: DataTypes.STRING, unique: true },
        password: DataTypes.STRING,
        plainPassword: DataTypes.STRING,
        groupKey: DataTypes.STRING,
        role: { type: DataTypes.STRING, defaultValue: 'Teacher' }
    }, { engine: 'InnoDB', rowFormat: 'DYNAMIC' });
}

function defineUserModel(db) {
    return db.define('User', {
        id: { type: DataTypes.STRING, primaryKey: true },
        profileId: { type: DataTypes.STRING, allowNull: false },
        fullName: DataTypes.STRING,
        campusName: DataTypes.STRING,
        email: { type: DataTypes.STRING, unique: true, allowNull: true },
        username: { type: DataTypes.STRING, unique: true, allowNull: false },
        password: { type: DataTypes.STRING, allowNull: false },
        plainPassword: DataTypes.STRING,
        groupKey: DataTypes.STRING,
        role: { type: DataTypes.STRING, allowNull: false },
        isActive: { type: DataTypes.BOOLEAN, defaultValue: true }
    }, { engine: 'InnoDB', rowFormat: 'DYNAMIC' });
}

function defineStaffModel(db) {
    return db.define('Staff', {
        id: { type: DataTypes.STRING, primaryKey: true },
        employeeCode: DataTypes.STRING,
        fullName: DataTypes.STRING,
        fatherName: DataTypes.STRING,
        dob: DataTypes.STRING,
        designation: DataTypes.STRING,
        cnic: DataTypes.STRING,
        phone: DataTypes.STRING,
        email: { type: DataTypes.STRING, unique: true, allowNull: true },
        address: DataTypes.TEXT,
        gender: DataTypes.STRING,
        salary: DataTypes.STRING,
        idCardFront: DataTypes.TEXT('long'),
        idCardBack: DataTypes.TEXT('long'),
        bankName: DataTypes.STRING,
        bankAccountTitle: DataTypes.STRING,
        bankAccountNumber: DataTypes.STRING,
        bankBranch: DataTypes.STRING,
        username: { type: DataTypes.STRING, unique: true, allowNull: true },
        password: DataTypes.STRING,
        plainPassword: DataTypes.STRING,
        groupKey: DataTypes.STRING,
        role: { type: DataTypes.STRING, defaultValue: 'Staff' }
    }, { engine: 'InnoDB', rowFormat: 'DYNAMIC' });
}

function defineFeePaymentModel(db) {
    return db.define('FeePayment', {
        challanNumber: { type: DataTypes.STRING, primaryKey: true },
        studentId: { type: DataTypes.STRING, allowNull: false },
        studentName: DataTypes.STRING,
        rollNo: DataTypes.STRING,
        classGrade: DataTypes.STRING,
        session: DataTypes.STRING,
        feeMonth: DataTypes.STRING,
        amount: DataTypes.DECIMAL(10, 2),
        status: { type: DataTypes.STRING, defaultValue: 'Pending' },
        paidAt: { type: DataTypes.DATE, allowNull: true },
        paymentDateLabel: DataTypes.STRING,
        paymentSource: DataTypes.STRING
    });
}

function defineFeeDueBalanceModel(db) {
    return db.define('FeeDueBalance', {
        studentId: { type: DataTypes.STRING, primaryKey: true },
        balance: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        updatedAtLabel: DataTypes.STRING
    });
}

function defineClassFeeModel(db) {
    return db.define('ClassFee', {
        id: { type: DataTypes.STRING, primaryKey: true },
        className: { type: DataTypes.STRING, allowNull: false },
        monthlyFee: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        annualCharges: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        feeFrequency: { type: DataTypes.STRING, defaultValue: 'Monthly' },
        feeMonth: DataTypes.STRING,
        feeYear: DataTypes.STRING,
        sessionFrom: DataTypes.STRING,
        sessionTo: DataTypes.STRING,
        updatedAtLabel: DataTypes.STRING
    });
}

function defineClassFeeHistoryModel(db) {
    return db.define('ClassFeeHistory', {
        id: { type: DataTypes.STRING, primaryKey: true },
        className: { type: DataTypes.STRING, allowNull: false },
        monthlyFee: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        annualCharges: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        feeFrequency: { type: DataTypes.STRING, defaultValue: 'Monthly' },
        feeMonth: DataTypes.STRING,
        feeYear: DataTypes.STRING,
        sessionFrom: DataTypes.STRING,
        sessionTo: DataTypes.STRING,
        updatedAtLabel: DataTypes.STRING
    });
}

function defineStudentDiaryModel(db) {
    return db.define('StudentDiary', {
        id: { type: DataTypes.STRING, primaryKey: true },
        campusName: { type: DataTypes.STRING, allowNull: true },
        classGrade: { type: DataTypes.STRING, allowNull: false },
        section: { type: DataTypes.STRING, allowNull: true },
        date: { type: DataTypes.STRING, allowNull: false },
        title: { type: DataTypes.STRING, allowNull: false },
        details: { type: DataTypes.TEXT('long'), allowNull: false },
        file: { type: DataTypes.TEXT('long'), allowNull: true },
        createdByRole: { type: DataTypes.STRING, allowNull: true },
        createdByTeacherId: { type: DataTypes.STRING, allowNull: true },
        teacherId: { type: DataTypes.STRING, allowNull: true },
        teacherName: { type: DataTypes.STRING, allowNull: true },
        createdAtLabel: { type: DataTypes.STRING, allowNull: true }
    });
}

function defineStudentPerformanceModel(db) {
    return db.define('StudentPerformance', {
        id: { type: DataTypes.STRING, primaryKey: true },
        studentId: { type: DataTypes.STRING, allowNull: false },
        studentName: { type: DataTypes.STRING, allowNull: false },
        classGrade: { type: DataTypes.STRING, allowNull: false },
        subject: { type: DataTypes.STRING, allowNull: false },
        examType: { type: DataTypes.STRING, allowNull: true },
        examYear: { type: DataTypes.STRING, allowNull: true },
        obtainedMarks: { type: DataTypes.DECIMAL(8, 2), allowNull: true },
        totalMarks: { type: DataTypes.DECIMAL(8, 2), allowNull: true },
        section: { type: DataTypes.STRING, allowNull: true },
        percentage: { type: DataTypes.DECIMAL(5, 2), allowNull: false, defaultValue: 0 },
        grade: { type: DataTypes.STRING, allowNull: true },
        skill: { type: DataTypes.STRING, allowNull: true },
        learningOutcome: { type: DataTypes.TEXT, allowNull: true },
        rating: { type: DataTypes.STRING, allowNull: true },
        excellentDescription: { type: DataTypes.TEXT, allowNull: true },
        satisfactoryDescription: { type: DataTypes.TEXT, allowNull: true },
        needsPracticeDescription: { type: DataTypes.TEXT, allowNull: true },
        performanceDate: { type: DataTypes.STRING, allowNull: true },
        performanceMonth: { type: DataTypes.STRING, allowNull: true },
        remarks: { type: DataTypes.TEXT, allowNull: true },
        updatedAtLabel: { type: DataTypes.STRING, allowNull: true }
    });
}

function defineStudentAttendanceModel(db) {
    return db.define('StudentAttendance', {
        id: { type: DataTypes.STRING, primaryKey: true },
        studentId: { type: DataTypes.STRING, allowNull: false },
        date: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.STRING, allowNull: false }
    });
}

function defineTeacherAttendanceModel(db) {
    return db.define('TeacherAttendance', {
        id: { type: DataTypes.STRING, primaryKey: true },
        teacherId: { type: DataTypes.STRING, allowNull: false },
        date: { type: DataTypes.STRING, allowNull: false },
        status: { type: DataTypes.STRING, allowNull: false }
    });
}

function defineSpecialNoticeModel(db) {
    return db.define('SpecialNotice', {
        id: { type: DataTypes.STRING, primaryKey: true },
        title: { type: DataTypes.STRING, allowNull: false },
        message: { type: DataTypes.TEXT('long'), allowNull: false },
        targetPortals: { type: DataTypes.TEXT('long'), allowNull: false },
        audienceType: { type: DataTypes.STRING, allowNull: true, defaultValue: 'portal' },
        targetClassGrade: { type: DataTypes.STRING, allowNull: true },
        status: { type: DataTypes.STRING, defaultValue: 'draft' },
        executedAt: { type: DataTypes.DATE, allowNull: true },
        createdAtLabel: DataTypes.STRING
    });
}

function defineMessageModel(db) {
    return db.define('Message', {
        id: { type: DataTypes.STRING, primaryKey: true },
        subject: { type: DataTypes.STRING, allowNull: false },
        body: { type: DataTypes.TEXT('long'), allowNull: false },
        targetRole: { type: DataTypes.STRING, allowNull: false },
        targetScope: { type: DataTypes.STRING, allowNull: false },
        campusName: { type: DataTypes.STRING, allowNull: true },
        classGrade: { type: DataTypes.STRING, allowNull: true },
        recipientId: { type: DataTypes.STRING, allowNull: true },
        recipientName: { type: DataTypes.STRING, allowNull: true },
        senderName: { type: DataTypes.STRING, allowNull: true },
        createdAtLabel: DataTypes.STRING
    });
}

function normalizeAttendanceStatus(status) {
    if (status === 'P') return 'Present';
    if (status === 'A') return 'Absent';
    if (status === 'Present' || status === 'Late' || status === 'Absent') return status;
    return 'Not Marked';
}

function buildStudentAttendanceStore(records) {
    return records.reduce((store, record) => {
        const studentId = String(record.studentId || '').trim();
        const date = String(record.date || '').trim();
        const status = normalizeAttendanceStatus(record.status);

        if (!studentId || !date || status === 'Not Marked') {
            return store;
        }

        if (!Array.isArray(store[studentId])) {
            store[studentId] = [];
        }

        store[studentId].push({ date, status });
        store[studentId].sort((a, b) => a.date.localeCompare(b.date));
        return store;
    }, {});
}

function buildTeacherAttendanceStore(records) {
    return records.reduce((store, record) => {
        const teacherId = String(record.teacherId || '').trim();
        const date = String(record.date || '').trim();
        const status = normalizeAttendanceStatus(record.status);

        if (!teacherId || !date || status === 'Not Marked') {
            return store;
        }

        const monthKey = date.slice(0, 7);
        const dayIndex = Number(date.slice(8, 10)) - 1;
        const recordKey = `${teacherId}_${monthKey}`;

        if (!Array.isArray(store[recordKey])) {
            const daysInMonth = new Date(Number(monthKey.slice(0, 4)), Number(monthKey.slice(5, 7)), 0).getDate();
            store[recordKey] = Array(daysInMonth).fill('Not Marked');
        }

        if (dayIndex >= 0 && dayIndex < store[recordKey].length) {
            store[recordKey][dayIndex] = status;
        }

        return store;
    }, {});
}

function getRequestBaseUrl(req) {
    return `${req.protocol}://${req.get('host')}`;
}

function renderFeePaymentPage({ title, message, details = [], success = true }) {
    const detailRows = details.map(({ label, value }) => `
        <div class="detail-row">
            <span>${label}</span>
            <strong>${value}</strong>
        </div>
    `).join('');

    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>${title}</title>
            <style>
                body {
                    margin: 0;
                    font-family: Arial, sans-serif;
                    background: #f4f7fb;
                    color: #1f2937;
                    display: grid;
                    place-items: center;
                    min-height: 100vh;
                    padding: 24px;
                }
                .card {
                    width: min(520px, 100%);
                    background: #fff;
                    border: 1px solid #dbe3ee;
                    border-radius: 20px;
                    box-shadow: 0 20px 50px rgba(15, 23, 42, 0.12);
                    padding: 28px;
                }
                .badge {
                    display: inline-block;
                    padding: 6px 12px;
                    border-radius: 999px;
                    background: ${success ? '#dcfce7' : '#fee2e2'};
                    color: ${success ? '#166534' : '#991b1b'};
                    font-size: 12px;
                    font-weight: 700;
                    margin-bottom: 14px;
                }
                h1 {
                    margin: 0 0 10px;
                    font-size: 28px;
                }
                p {
                    margin: 0 0 20px;
                    color: #475569;
                    line-height: 1.6;
                }
                .details {
                    display: grid;
                    gap: 12px;
                    margin-top: 18px;
                }
                .detail-row {
                    display: flex;
                    justify-content: space-between;
                    gap: 16px;
                    padding: 12px 14px;
                    border: 1px solid #e2e8f0;
                    border-radius: 12px;
                    background: #f8fafc;
                }
                .detail-row span {
                    color: #64748b;
                    font-size: 14px;
                }
                .detail-row strong {
                    text-align: right;
                    font-size: 14px;
                }
            </style>
        </head>
        <body>
            <section class="card">
                <div class="badge">${success ? 'Payment Captured' : 'Payment Failed'}</div>
                <h1>${title}</h1>
                <p>${message}</p>
                <div class="details">${detailRows}</div>
            </section>
        </body>
        </html>
    `;
}

async function upsertAuthUser(User, payload) {
    if (!payload.username || !payload.password || !payload.profileId || !payload.role) {
        return;
    }

    await User.upsert({
        id: payload.id,
        profileId: payload.profileId,
        fullName: payload.fullName || '',
        campusName: payload.campusName || null,
        email: normalizeOptionalEmail(payload.email),
        username: payload.username,
        password: payload.password,
        plainPassword: payload.plainPassword || null,
        role: payload.role,
        groupKey: payload.groupKey || null,
        isActive: true
    });
}

async function syncAuthUsers() {
    const Student = sequelize.models.Student;
    const Teacher = sequelize.models.Teacher;
    const User = sequelize.models.User;

    const students = await Student.findAll({
        attributes: ['id', 'fullName', 'campusName', 'email', 'username', 'password', 'plainPassword']
    });
    for (const student of students) {
        await upsertAuthUser(User, {
            id: `student_${student.id}`,
            profileId: student.id,
            fullName: student.fullName,
            campusName: student.campusName || null,
            email: normalizeOptionalEmail(student.email),
            username: student.username,
            password: student.password,
            plainPassword: student.plainPassword || null,
            role: 'Student'
        });
    }

    const teachers = await Teacher.findAll({
        attributes: ['id', 'fullName', 'campusName', 'email', 'username', 'password', 'plainPassword', 'groupKey']
    });
    for (const teacher of teachers) {
        await upsertAuthUser(User, {
            id: `teacher_${teacher.id}`,
            profileId: teacher.id,
            fullName: teacher.fullName,
            campusName: teacher.campusName || null,
            email: normalizeOptionalEmail(teacher.email),
            username: teacher.username,
            password: teacher.password,
            plainPassword: teacher.plainPassword || null,
            groupKey: teacher.groupKey || 'teacher',
            role: 'Teacher'
        });
    }

    const Staff = sequelize.models.Staff;
    const staffMembers = await Staff.findAll({
        attributes: ['id', 'fullName', 'email', 'username', 'password', 'plainPassword', 'groupKey']
    });
    for (const member of staffMembers) {
        await upsertAuthUser(User, {
            id: `staff_${member.id}`,
            profileId: member.id,
            fullName: member.fullName,
            email: normalizeOptionalEmail(member.email),
            username: member.username,
            password: member.password,
            plainPassword: member.plainPassword || null,
            groupKey: member.groupKey || 'staff',
            role: 'Staff'
        });
    }
}

async function ensureTableColumns(tableName, columnDefinitions) {
    const queryInterface = sequelize.getQueryInterface();
    const table = await queryInterface.describeTable(tableName);

    for (const [columnName, definition] of Object.entries(columnDefinitions)) {
        if (!table[columnName]) {
            await queryInterface.addColumn(tableName, columnName, definition);
        }
    }
}

async function removeLegacyStudentPerformanceUniqueIndex() {
    const queryInterface = sequelize.getQueryInterface();
    try {
        const indexes = await queryInterface.showIndex('StudentPerformances');
        for (const index of indexes) {
            const fields = (index.fields || []).map((field) => field.attribute || field.name).filter(Boolean);
            if (index.unique && fields.length === 2 && fields.includes('studentId') && fields.includes('subject')) {
                await queryInterface.removeIndex('StudentPerformances', index.name);
            }
        }
    } catch (_error) {
        // The table may not exist yet on first startup; sync will create it.
    }
}

async function ensureLegacySchema() {
    await ensureTableColumns('ClassFees', {
        annualCharges: { type: DataTypes.DECIMAL(10, 2), defaultValue: 0 },
        feeMonth: { type: DataTypes.STRING, allowNull: true },
        feeYear: { type: DataTypes.STRING, allowNull: true },
        sessionFrom: { type: DataTypes.STRING, allowNull: true },
        sessionTo: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('Students', {
        studentCode: { type: DataTypes.STRING, allowNull: true },
        fullName: { type: DataTypes.STRING, allowNull: true },
        profileImage: { type: DataTypes.TEXT('long'), allowNull: true },
        fatherName: { type: DataTypes.STRING, allowNull: true },
        dob: { type: DataTypes.STRING, allowNull: true },
        admissionDate: { type: DataTypes.STRING, allowNull: true },
        classGrade: { type: DataTypes.STRING, allowNull: true },
        section: { type: DataTypes.STRING, allowNull: true },
        subjects: { type: DataTypes.TEXT, allowNull: true },
        campusName: { type: DataTypes.STRING, allowNull: true },
        gender: { type: DataTypes.STRING, allowNull: true },
        parentPhone: { type: DataTypes.STRING, allowNull: true },
        email: { type: DataTypes.STRING, allowNull: true },
        rollNo: { type: DataTypes.STRING, allowNull: true },
        formB: { type: DataTypes.STRING, allowNull: true },
        cnic: { type: DataTypes.STRING, allowNull: true },
        monthlyFee: { type: DataTypes.STRING, allowNull: true },
        monthlyFeeCustom: { type: DataTypes.BOOLEAN, allowNull: true },
        freeStudy: { type: DataTypes.BOOLEAN, allowNull: true },
        zeroFeeReason: { type: DataTypes.TEXT, allowNull: true },
        remainingAmount: { type: DataTypes.STRING, allowNull: true },
        dueBalance: { type: DataTypes.STRING, allowNull: true },
        balance: { type: DataTypes.STRING, allowNull: true },
        feeFrequency: { type: DataTypes.STRING, allowNull: true },
        feesStatus: { type: DataTypes.STRING, allowNull: true },
        enrollmentStatus: { type: DataTypes.STRING, allowNull: true },
        paymentDate: { type: DataTypes.STRING, allowNull: true },
        address: { type: DataTypes.TEXT, allowNull: true },
        guardianName: { type: DataTypes.STRING, allowNull: true },
        guardianContact: { type: DataTypes.STRING, allowNull: true },
        fingerprintData: { type: DataTypes.TEXT('long'), allowNull: true },
        familyId: { type: DataTypes.STRING, allowNull: true },
        familyName: { type: DataTypes.STRING, allowNull: true },
        familyNo: { type: DataTypes.STRING, allowNull: true },
        familyContact: { type: DataTypes.STRING, allowNull: true },
        familyAddedAt: { type: DataTypes.STRING, allowNull: true },
        username: { type: DataTypes.STRING, allowNull: true },
        password: { type: DataTypes.STRING, allowNull: true },
        plainPassword: { type: DataTypes.STRING, allowNull: true },
        role: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('Users', {
        fullName: { type: DataTypes.STRING, allowNull: true },
        campusName: { type: DataTypes.STRING, allowNull: true },
        email: { type: DataTypes.STRING, allowNull: true },
        username: { type: DataTypes.STRING, allowNull: false },
        password: { type: DataTypes.STRING, allowNull: false },
        plainPassword: { type: DataTypes.STRING, allowNull: true },
        groupKey: { type: DataTypes.STRING, allowNull: true },
        role: { type: DataTypes.STRING, allowNull: false },
        isActive: { type: DataTypes.BOOLEAN, allowNull: true }
    });

    await ensureTableColumns('Teachers', {
        employeeCode: { type: DataTypes.STRING, allowNull: true },
        fullName: { type: DataTypes.STRING, allowNull: true },
        profileImage: { type: DataTypes.TEXT('long'), allowNull: true },
        fatherName: { type: DataTypes.STRING, allowNull: true },
        dob: { type: DataTypes.STRING, allowNull: true },
        cnic: { type: DataTypes.STRING, allowNull: true },
        phone: { type: DataTypes.STRING, allowNull: true },
        email: { type: DataTypes.STRING, allowNull: true },
        address: { type: DataTypes.TEXT, allowNull: true },
        qualification: { type: DataTypes.STRING, allowNull: true },
        campusName: { type: DataTypes.STRING, allowNull: true },
        gender: { type: DataTypes.STRING, allowNull: true },
        designation: { type: DataTypes.STRING, allowNull: true },
        subject: { type: DataTypes.STRING, allowNull: true },
        assignedSections: { type: DataTypes.TEXT, allowNull: true },
        salary: { type: DataTypes.STRING, allowNull: true },
        idCardFront: { type: DataTypes.TEXT('long'), allowNull: true },
        idCardBack: { type: DataTypes.TEXT('long'), allowNull: true },
        cvFile: { type: DataTypes.TEXT('long'), allowNull: true },
        bankName: { type: DataTypes.STRING, allowNull: true },
        bankAccountTitle: { type: DataTypes.STRING, allowNull: true },
        bankAccountNumber: { type: DataTypes.STRING, allowNull: true },
        bankBranch: { type: DataTypes.STRING, allowNull: true },
        schedule: { type: DataTypes.TEXT('long'), allowNull: true },
        username: { type: DataTypes.STRING, allowNull: true },
        password: { type: DataTypes.STRING, allowNull: true },
        plainPassword: { type: DataTypes.STRING, allowNull: true },
        groupKey: { type: DataTypes.STRING, allowNull: true },
        role: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('Staffs', {
        employeeCode: { type: DataTypes.STRING, allowNull: true },
        fullName: { type: DataTypes.STRING, allowNull: true },
        fatherName: { type: DataTypes.STRING, allowNull: true },
        dob: { type: DataTypes.STRING, allowNull: true },
        designation: { type: DataTypes.STRING, allowNull: true },
        cnic: { type: DataTypes.STRING, allowNull: true },
        phone: { type: DataTypes.STRING, allowNull: true },
        email: { type: DataTypes.STRING, allowNull: true },
        address: { type: DataTypes.TEXT, allowNull: true },
        gender: { type: DataTypes.STRING, allowNull: true },
        salary: { type: DataTypes.STRING, allowNull: true },
        idCardFront: { type: DataTypes.TEXT('long'), allowNull: true },
        idCardBack: { type: DataTypes.TEXT('long'), allowNull: true },
        bankName: { type: DataTypes.STRING, allowNull: true },
        bankAccountTitle: { type: DataTypes.STRING, allowNull: true },
        bankAccountNumber: { type: DataTypes.STRING, allowNull: true },
        bankBranch: { type: DataTypes.STRING, allowNull: true },
        username: { type: DataTypes.STRING, allowNull: true },
        password: { type: DataTypes.STRING, allowNull: true },
        plainPassword: { type: DataTypes.STRING, allowNull: true },
        groupKey: { type: DataTypes.STRING, allowNull: true },
        role: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('Messages', {
        subject: { type: DataTypes.STRING, allowNull: false },
        body: { type: DataTypes.TEXT('long'), allowNull: false },
        targetRole: { type: DataTypes.STRING, allowNull: false },
        targetScope: { type: DataTypes.STRING, allowNull: false },
        campusName: { type: DataTypes.STRING, allowNull: true },
        classGrade: { type: DataTypes.STRING, allowNull: true },
        recipientId: { type: DataTypes.STRING, allowNull: true },
        recipientName: { type: DataTypes.STRING, allowNull: true },
        senderName: { type: DataTypes.STRING, allowNull: true },
        createdAtLabel: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('SpecialNotices', {
        audienceType: { type: DataTypes.STRING, allowNull: true },
        targetClassGrade: { type: DataTypes.STRING, allowNull: true }
    });

    await ensureTableColumns('StudentPerformances', {
        section: { type: DataTypes.STRING, allowNull: true },
        examType: { type: DataTypes.STRING, allowNull: true },
        examYear: { type: DataTypes.STRING, allowNull: true },
        obtainedMarks: { type: DataTypes.DECIMAL(8, 2), allowNull: true },
        totalMarks: { type: DataTypes.DECIMAL(8, 2), allowNull: true },
        skill: { type: DataTypes.STRING, allowNull: true },
        learningOutcome: { type: DataTypes.TEXT, allowNull: true },
        rating: { type: DataTypes.STRING, allowNull: true },
        excellentDescription: { type: DataTypes.TEXT, allowNull: true },
        satisfactoryDescription: { type: DataTypes.TEXT, allowNull: true },
        needsPracticeDescription: { type: DataTypes.TEXT, allowNull: true },
        performanceDate: { type: DataTypes.STRING, allowNull: true },
        performanceMonth: { type: DataTypes.STRING, allowNull: true }
    });
    await ensureTableColumns('StudentDiaries', {
        section: { type: DataTypes.STRING, allowNull: true }
    });
    await removeLegacyStudentPerformanceUniqueIndex();
}

async function startServer() {
    if (startupPromise) {
        return startupPromise;
    }

    startupPromise = (async () => {
    try {
        startupError = null;
        startupErrorCode = null;
        console.log('Initializing database...');
        await initializeDatabase();

        sequelize = new Sequelize(
            process.env.DB_NAME || 'school_system',
            process.env.DB_USER || 'root',
            process.env.DB_PASSWORD || '',
            {
                host: process.env.DB_HOST || 'localhost',
                port: Number(process.env.DB_PORT || 3306),
                dialect: 'mysql',
                logging: false
            }
        );

        defineStudentModel(sequelize);
        defineTeacherModel(sequelize);
        defineUserModel(sequelize);
        defineStaffModel(sequelize);
        defineFeePaymentModel(sequelize);
        defineFeeDueBalanceModel(sequelize);
        defineClassFeeModel(sequelize);
        defineClassFeeHistoryModel(sequelize);
        defineStudentDiaryModel(sequelize);
        defineStudentPerformanceModel(sequelize);
        defineStudentAttendanceModel(sequelize);
        defineTeacherAttendanceModel(sequelize);
        defineSpecialNoticeModel(sequelize);
        defineMessageModel(sequelize);

        await sequelize.authenticate();
        // The Students screen is the first database-backed admin view. Ensure
        // its table exists before the remainder of the schema is synchronized.
        await sequelize.models.Student.sync();

        // Avoid Sequelize's repeated ALTER-based index churn on MySQL.
        // Missing legacy columns are handled separately in ensureLegacySchema().
        await sequelize.sync();
        await ensureLegacySchema();
        await syncAuthUsers();
        console.log('✅ Database synced successfully');

        isInitialized = true;
        startupError = null;
        startupErrorCode = null;
    } catch (err) {
        startupPromise = null;
        isInitialized = false;
        startupError = err?.message || 'Database initialization failed.';
        startupErrorCode = classifyDatabaseError(err);
        console.error('Database connection error:', err.message);
        console.log('Ensure MySQL is running and .env credentials are correct.');
        throw err;
    }
    })();

    return startupPromise;
}

module.exports = {
    app,
    startServer,
    server,
    io,
    getSequelize: () => sequelize,
    isInitialized: () => isInitialized
};

if (require.main === module) {
    const PORT = Number(process.env.PORT || 3001);
    server.listen(PORT, '0.0.0.0', () => {
        console.log(`Real-Time SQL Server running on port ${PORT}`);
        startServer().catch((err) => {
            console.error('Startup background initialization failed:', err?.message || err);
        });
    });
}
